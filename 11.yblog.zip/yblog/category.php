<html><head>
<title>Y! Simple Blog</title>
<script src="quill.js"></script>
<link href="quill+bootstrap.min.css" rel="stylesheet"><style>
.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
    padding-left: 10%;
}

/* Style the buttons inside the tab */
.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #ddd;
}
/* Create an active/current tablink class */
.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style></head><body>
<div class="jumbotron text-center">
  <h1><span style="color:red;">Y!</span><span style="vertical-align:center"> Simple Blog</span></h1>
<div class="tab">
  <button class="tablinks" onclick="javascript:(location.href='index.php')">Index</button>
  <button class="tablinks" onclick="javascript:(location.href='editor.php')">Add Post</button>
  <button class="tablinks" onclick="javascript:(location.href='add_category.php')">Add Category</button>
  <button class="tablinks active" onclick="javascript:(location.href='category.php')">Category List</button>
</div>
</div>
<div class="container">
<div class="center-block col-sm-10">
<div class="col-sm-offset-2 col-sm-10">
<?php
$conn = new mysqli('localhost', 'admin', '', 'yblog');


if(empty($_GET)){
echo '<h2 class="text-center center-block"><b style="color:red;">Category</b></h2>';
$sql=$conn->query("SELECT * FROM categories");
if ($sql->num_rows > 0) {
while($row = $sql->fetch_assoc()) {
echo "<h4><a href='category.php?id=".$row["id"]."'>".$row["name"]."</a></h4>";
}
}
$conn->close();
}if ($_GET["action"]=="delete" && !empty($_GET["id"])){
echo '<center><form action="" method="GET"><h2>Delete this article</h2>
<input type="hidden" name="action" value="'.$_GET["action"].'">
<input type="hidden" name="id" value="'.$_GET["id"].'">
<div class="btn-group btn-md ">
    <button type="submit" name="sub" value="delete" class="btn btn-danger">Delete</button>
    <button type="submit" name="sub" value="cancel" class="btn btn-warning">Cancel</button>
</div></form></center>';
if ($_GET["sub"]=="delete"){
$sql=$conn->query("DELETE FROM posts WHERE id='".$_GET["id"]."'")->fetch_assoc();
$conn->close();
header('Location: category.php');
}if ($_GET["sub"]=="cancel"){
header('Location: category.php?id='.$_GET["id"]);
}
}
else{
$qry=$conn->query("SELECT * FROM categories WHERE id='".$_GET["id"]."'")->fetch_assoc();
echo '<center><h2 class="text-center center-block"><b style="color:red;"><a href="category.php" style="color:red;text-decoration:none">Category ::</a> '.$qry["name"].'</b></h2><a href="category.php?action=delete&id='.$_GET["id"].'">DELETE</a></center>';
$sql=$conn->query("SELECT * FROM posts WHERE cat_id='".$_GET["id"]."'");
if ($sql->num_rows > 0) {
while($row = $sql->fetch_assoc()) {
echo "<h4><a href='index.php?action=read&id=".$row["id"]."'>".$row["title"]."</a></h4>";
}
}
$conn->close();
}
?>     
</div><div><div>
</body></html>
