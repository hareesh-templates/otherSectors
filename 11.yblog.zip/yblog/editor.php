<?php
$conn = new mysqli('localhost', 'admin', '', 'yblog');
session_start();
?>
<html><head>
<title>Y! Simple Blog</title>
<script src="quill.js"></script>
<link href="quill+bootstrap.min.css" rel="stylesheet"><style>
.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
    padding-left: 10%;
}

/* Style the buttons inside the tab */
.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #ddd;
}
/* Create an active/current tablink class */
.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style></head><body>
<div class="jumbotron text-center">
  <h1><span style="color:red;">Y!</span><span style="vertical-align:center"> Simple Blog</span></h1>
<div class="tab btn-group btn-group-justified">
  <button class="tablinks" onclick="javascript:(location.href='index.php')">Index</button>
  <button class="tablinks active" onclick="javascript:(location.href='editor.php')">Add Post</button>
  <button class="tablinks" onclick="javascript:(location.href='add_category.php')">Add Category</button>
  <button class="tablinks" onclick="javascript:(location.href='category.php')">Category List</button>
</div>
</div><div class="container" style="padding-bottom:5em"><center>
<?php
if($_POST["sub"]=="edit"){
$edit=$conn->query("UPDATE posts SET title='".$_POST["title"]."', cat_id='".$_POST["category"]."', text='".$_POST["text"]."', date='".date("Y/m/d h:i:s")."' WHERE id='".$_POST["id"]."'");
$conn->close();
header ('Location: index.php?action=read&id='.$_POST["id"]);
}
if($_POST["sub"]=="add"){
$edit=$conn->query("INSERT INTO posts SET title='".$_POST["title"]."', cat_id='".$_POST["category"]."', text='".$_POST["text"]."', date='".date("Y/m/d h:i:s")."'");
$last_id = $conn->insert_id;
$conn->close();
header ('Location: index.php?action=read&id='.$last_id);
}

$qry=$conn->query("SELECT * FROM posts WHERE id='".$_GET["id"]."'")->fetch_assoc();
echo "<h2>".(empty($_GET["id"])?'Add an Article':'Update Article')."</h2>
<form action='' method='POST'><table width='88%'>
<tr><td width='20%' class='lead'>Title</td><td><input type='text' name='title' class='form-control' placeholder='Enter Title Here' value='".$qry["title"]."' required></td></tr>
<tr><td colspan='2'><input type='hidden' name='id' value='".$qry["id"]."'><input type='hidden' name='text'>
<div id='editor' class='form-control' style='padding:0em;height:18em'>".$qry["text"]."</div></td></tr>
<tr><td class='lead'>Category</td><td><select type='text' name='category' class='form-control' required>";
$sql=$conn->query("SELECT * FROM categories ORDER BY date DESC");
if ($sql->num_rows > 0) {
while($row = $sql->fetch_assoc()) {
echo "<option value='".$row["id"]."' ".($row["id"]==$qry["cat_id"]?'selected':'').">".$row["name"]."</option>";
}
}
$conn->close();
echo "</select></td></tr>
<tr><td colspan='2'><button type='submit' class='btn btn-default btn-block btn-lg btn-success' name='sub' value='".(empty($_GET["id"])?'add':'edit')."'>Submit</button></td></tr>
</table></form>";
?></center></div>
</body></html>
<script>
  var quill = new Quill('#editor', {
    modules: {
    toolbar: [
    [{header: []}, {font: []}], 
    ['bold', 'italic', 'underline', 'strike', 'link'], 
    [{align: []},{list: 'bullet'},{list: 'ordered'}, {color:[]}, {background:[]}, 'image', 'video'], 
    ]
  },
  placeholder: 'Compose an epic...',
  
  
    theme: 'snow'
  });
  var form = document.querySelector('form');
form.onsubmit = function() {
  // Populate hidden form on submit
  var about = document.querySelector('input[name=text]');
  about.value = quill.root.innerHTML;
  
  console.log("Submitted", $(form).serialize(), $(form).serializeArray());
  
  // No back end to actually submit to!
  alert('Open the console to see the submit data!')
  return false;
};
</script>