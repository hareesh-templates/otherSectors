<html><head>
<title>Y! Simple Blog</title>
<script src="quill.js"></script>
<link href="quill+bootstrap.min.css" rel="stylesheet"><style>
.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
    padding-left: 10%;
}

/* Style the buttons inside the tab */
.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #ddd;
}
/* Create an active/current tablink class */
.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style></head><body>
<div class="jumbotron text-center">
  <h1><span style="color:red;">Y!</span><span style="vertical-align:center"> Simple Blog</span></h1>
<div class="tab">
  <button class="tablinks" onclick="javascript:(location.href='index.php')">Index</button>
  <button class="tablinks" onclick="javascript:(location.href='editor.php')">Add Post</button>
  <button class="tablinks active" onclick="javascript:(location.href='add_category.php')">Add Category</button>
  <button class="tablinks" onclick="javascript:(location.href='category.php')">Category List</button>
</div>
</div>
<div class="container">
<div class="center-block col-sm-10">
      <div class="col-sm-offset-2 col-sm-10">
      <h2 class="text-center center-block"><b style="color:red;">Add Category</b></h2>
      <form action='' method='POST'>
      <p><input type="text" class="form-control" name="category" placeholder="Enter name of Category" required ></p>
        <button type="submit" class="btn btn-default btn-block" name="sub" value="add">Submit</button>
      </form>
<?php
$conn = new mysqli('localhost', 'admin', '', 'yblog');
if($_POST["sub"]=="add"){
$qry=$conn->query("SELECT * FROM categories WHERE name='".$_POST["category"]."'")->fetch_assoc();
if($_POST["category"]!=$qry["name"]){
$sql=$conn->query("INSERT INTO categories SET name='".$_POST["category"]."', date='".date("Y/m/d h:i:s")."'");
echo '<span class="center-block well text-success">Category has been added.</span>';
}else{
echo '<span class="center-block well text-danger">This category already exist. Please try a different Category.</span>';
}
$conn->close();
}
?>    
</div>    
<div><div>
</body></html>
