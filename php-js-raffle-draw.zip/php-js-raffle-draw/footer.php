
</body>
<footer class="container-fluid py-3">
    <div class="container-fluid my-2">
        <div class="text-center">
            Raffle Draw System - PHP & JS &copy; <?= date("Y") ?>
        </div>
    </div>
</footer>
<script src="script.js"></script>
</html>