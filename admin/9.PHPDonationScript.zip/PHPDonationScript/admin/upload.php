<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php error_reporting(0); $digtrkf = "uploads/"; if(isset($_FILES["myfile"])) { $wstvfj = array(); $jrzbfi =$_FILES["myfile"]["error"]; if(!is_array($_FILES["myfile"]["name"])) { $siojqmj = $_FILES["myfile"]["name"]; $kprsk = pathinfo($siojqmj, PATHINFO_EXTENSION); if($kprsk=="png"||$kprsk=="jpg"||$kprsk=="jpeg"||$kprsk=="gif"||$kprsk=="PNG"||$kprsk=="JPG"||$kprsk=="JPEG"||$kprsk=="GIF") { $ehkdm=getimagesize($_FILES["myfile"]["tmp_name"]); $nrkhgo = $ehkdm['mime']; if(substr($nrkhgo, 0, 6) != 'image/'||$ehkdm[0]==0||$ehkdm[1]==0) { } else { move_uploaded_file($_FILES["myfile"]["tmp_name"],$digtrkf.$siojqmj); $wstvfj[]= $siojqmj; } } } else { $yphf = count($_FILES["myfile"]["name"]); for($i=0; $i < $yphf; $i++) { $siojqmj = $_FILES["myfile"]["name"][$i]; $kprsk = pathinfo($siojqmj, PATHINFO_EXTENSION); if($kprsk=="png"||$kprsk=="jpg"||$kprsk=="jpeg"||$kprsk=="gif"||$kprsk=="PNG"||$kprsk=="JPG"||$kprsk=="JPEG"||$kprsk=="GIF") { $ehkdm=getimagesize($_FILES["myfile"]["tmp_name"]); $nrkhgo = $ehkdm['mime']; if(substr($nrkhgo, 0, 6) != 'image/'||$ehkdm[0]==0||$ehkdm[1]==0) { } else { move_uploaded_file($_FILES["myfile"]["tmp_name"][$i],$digtrkf.$siojqmj); $wstvfj[]= $siojqmj; } } } } echo json_encode($wstvfj); } ?>