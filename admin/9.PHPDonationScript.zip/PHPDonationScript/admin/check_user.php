<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php define("LOGIN_PAGE", "login.php"); define("SUCCESS_PAGE", "index.php"); define("LOGIN_EXPIRE_AFTER", 24 * 3600); if((!isset($_COOKIE["AuthUser"]))||$_COOKIE["AuthUser"]=="") { die("<script>document.location.href=\"".LOGIN_PAGE."?error=expired\";</script>"); } else { list($lgmce,$esmnm,$ocfbs)=explode("~",$_COOKIE["AuthUser"]); if($ocfbs<time()) { die("<script>document.location.href=\"".LOGIN_PAGE."?error=expired\";</script>"); } else { $wjucxe = parse_ini_file("../config.php",true); if ( $esmnm!=$wjucxe["login"]["admin_password"] || $lgmce!=$wjucxe["login"]["admin_user"] ) { die("<script>document.location.href=\"".LOGIN_PAGE."?error=expired\";</script>"); } } } ?>