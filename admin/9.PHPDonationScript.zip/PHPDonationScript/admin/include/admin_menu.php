<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php $ejuvs = array( 1 => array( "name" => 'dashboard', "file" => 'home', "icon" => 'ti-layers' ), 2 => array( "name" => 'new_post', "file" => 'add', "icon" => 'ti-pencil-alt' ), 3 => array( "name" => 'my_posts', "file" => 'posts', "icon" => 'ti-clipboard' ), 4 => array( "name" => 'blog_categories', "file" => 'categories', "icon" => 'ti-folder' ), 5 => array( "name" => 'settings', "file" => 'settings', "icon" => 'ti-settings' ), 6 => array( "name" => 'site_information', "file" => 'site_information', "icon" => 'ti-comment-alt' ), 7 => array( "name" => 'Upgrade to Pro', "file" => 'pro', "icon" => 'ti-loop' ), 8 => array( "name" => 'PHP Scripts', "file" => 'scripts', "icon" => 'ti-server' ), 9 => array( "name" => 'logout', "file" => 'logout', "icon" => 'ti-shift-right' ) ); foreach($ejuvs as $ofzm) { $cfzzif=false; if(isset($_REQUEST["page"])&&$_REQUEST["page"]==$ofzm["file"]) { $cfzzif=true; } else if(!isset($_REQUEST["page"])&&$ofzm["file"]=="home") { $cfzzif=true; } echo "<li ".($cfzzif?"class=\"active\"":"")."> <a href=\"".($ofzm["file"]=="logout"?"logout.php":"index.php?page=".$ofzm["file"])."\"> <i class=\"".$ofzm["icon"]."\"></i> <p>".(isset($this->jeoih[$ofzm["name"]])?$this->jeoih[$ofzm["name"]]:$ofzm["name"])."</p> </a> </li>"; } ?>