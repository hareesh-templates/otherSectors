<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php if(!isset($_COOKIE["AuthUser"])) { ?> <a target="_blank" href="http://www.netartmedia.net/en_Contact.html" class="top-right-link"><img src="images/contact.png"/> <?php echo $this->jeoih["have_questions"];?> </a> <?php } else { ?> <li class="dropdown"> <a href="#"> <p class="notification" id="top_notification"> </p> </a> </li> <li> <a href="../index.php" target="_blank"> <i class="xti-settings"></i> <p><?php echo $this->jeoih["open_main_site"];?></p> </a> </li> <li> <a href="logout.php"> <i class="ti-shift-right"></i> <p><?php echo $this->jeoih["logout"];?></p> </a> </li> <?php } ?> 