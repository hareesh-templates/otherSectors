<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php define("LOGIN_PAGE", "login.php"); define("SUCCESS_PAGE", "index.php?login=1"); define("LOGIN_EXPIRE_AFTER", 24 * 3600); if(!isset($_POST["username"]) || !isset($_POST["password"]) || trim($_POST["username"]) == "" || trim($_POST["password"]) == "") { die("<script>document.location.href='".LOGIN_PAGE."?error=no';</script>"); } else { $wjucxe = parse_ini_file("../config.php",true); $lndfd="D58X1W"; if ( md5($_POST["password"].$lndfd)==$wjucxe["login"]["admin_password"] && $_POST["username"]==$wjucxe["login"]["admin_user"] ) { $ybvwfzc=$_POST["username"]."~".md5($_POST["password"].$lndfd)."~".(time()+LOGIN_EXPIRE_AFTER); setcookie("AuthUser",$ybvwfzc, (time()+LOGIN_EXPIRE_AFTER)); die("<script>document.location.href='".SUCCESS_PAGE."';</script>"); } else { die("<script>document.location.href=\"".LOGIN_PAGE."?error=error\";</script>"); } } ?>