To install PHP Donation Script on your website, you need
to unzip PHPDonationScript.zip and upload its files to your website's main folder 
or a sub folder like /donations or another one you may prefer.

As soon as you upload the files, you'll be able to access the administration panel on:

[your installation folder]/admin 

and the default username and password will be -

username: administrator
password: abc123

For example if you upload it on:

https://www.yourdomain.com/donations

then the administration panel will be available on:

https://www.yourdomain.com/donations/admin
username: administrator
password: abc123

Please note that you are required to keep the Powered By link at the bottom of the site.

If you would like the Powered By link to be removed, please upgrade to the PRO version https://www.netartmedia.net/php-donation#pro 
and get also access to the full source codes, free installation, free technical support and extra features.

For any questions or suggestions, please don't hesitate to contact us at:
https://www.netartmedia.net/contact

You are welcome to check also our other php scripts and website tools at:
https://www.netartmedia.net/products