; <?php exit;?>

[login]
admin_user = "administrator"
admin_password = "da1907216877e31462c14b35db67de32"

[website]
accent_color = ""
font_name = "Default"
font_size = "Default"
seo_urls = "0"
date_format = "F jS, Y"
currency="$"
currency_code="USD"
results_per_page = "10"
admin_email = "info@domain.com"
use_captcha_images = "1"
time_zone = "America/New_York"
image_quality = "90"
max_image_width = "800"
show_results = ""
only_one_per_ip = ""

