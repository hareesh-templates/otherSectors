<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?> <form action="index.php" method="post" class="main-search-form"> <input type="hidden" name="page" value="posts"/> <input type="hidden" name="proceed_search" value="1"/> <input required placeholder="<?php echo $this->jeoih["search"];?> ..." class="main-search-field" name="keyword_search" value="<?php if(isset($_REQUEST["keyword_search"])) echo strip_tags(stripslashes($_REQUEST["keyword_search"]));?>"/> <input type="image" src="images/search_icon.png"/> </form> 