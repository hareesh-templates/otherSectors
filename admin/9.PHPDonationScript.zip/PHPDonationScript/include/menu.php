<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?> <?php $taij = file_get_contents('include/categories.php'); $qgebp = explode("\n", trim($taij)); foreach($qgebp as $edxtk) { list($key,$uzscue)=explode(". ",$edxtk); $lyqjji = $this->lyqjji($key, $uzscue); echo '<li class="nav-item"><a class="nav-link" href="'.$lyqjji.'">'.$uzscue.'</a></li>'; } echo '<li class="nav-item"><a class="nav-link" href="'.$this->djtiffm("contact").'">'.$this->jeoih["contact_link"].'</a></li>'; ?> 