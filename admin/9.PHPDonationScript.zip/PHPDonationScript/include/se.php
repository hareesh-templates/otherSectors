<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php require('si.php'); session_start(); $zjjkt = new SecurityImage(150, 30); if ($zjjkt->pxmyhrxg()) { $_SESSION['code'] = md5($zjjkt->qmxydxp()); } else { echo 'Image GIF library is not installed.'; } ?>