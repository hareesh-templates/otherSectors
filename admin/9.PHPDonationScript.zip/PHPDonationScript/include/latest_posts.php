<?php
// PHP Donation Script Free Version - https://www.netartmedia.net/php-donation
// A software product of NetArt Media, All Rights Reserved
// The following source codes are obfuscated / made difficult to edit. 
// When upgrading to PHP Donation Script PRO, you get the full non-obfuscated source codes, 
// free technical support, free installation 
// and also extra features - please find details on:
// https://www.netartmedia.net/php-donation#pro
// Find out more PHP scripts and ready-made website systems on:
// https://www.netartmedia.net/products
?><?php $listings = simplexml_load_file($this->ibvbmme); $jiti = array(); foreach ($listings->listing as $xnvtau) $jiti[] = $xnvtau; $jiti = array_reverse($jiti); $hfjbg = 0; $ciwcaw=sizeof($jiti); $glcjhij=0; foreach ($jiti as $listing) { if($glcjhij>=2) break; $ciwcaw--; $zayua=$this->vfkwdns($ciwcaw,$listing->title); ?> <li> <hr class="hr-small"> <a href="<?php echo $zayua;?>"><small> <?php if(trim($listing->images) != "") { $agyk=explode(",",$listing->images); if(file_exists("thumbnails/".$agyk[0].".jpg")) { echo '<img src="thumbnails/'.$agyk[0].'.jpg" alt="'.$listing->title.'" class="bottom-image" align="left"/>'; } } ?> <?php echo $listing->title;?> </small></a> <div class="clearfix"></div> </li> <?php $glcjhij++; } ?>