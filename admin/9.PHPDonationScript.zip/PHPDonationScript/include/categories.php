1. Education
2. Healthcare