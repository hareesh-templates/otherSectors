$(window).load(function(){
    
    // ieCheck
    var ie = false;
    var aniButtonDuration = 350;
	 var defMh = 0, h = 0;
	 defMh = parseInt($('body').css('minHeight'));
    
    if($.browser.msie && $.browser.version<9)
    {
        aniButtonDuration = 0;
        ie = true;
    }
    
    
    $('.gall_spinner').hide();
    $('#bgStretch')
		.bgStretch({
			align:'rightTop',
			navigs:$('#bgNav').navigs({prevBtn:$('#prev_arr'), nextBtn:$('#next_arr')})
		}).sImg({
			spinner:$('.gall_spinner')
		}) 
        
		  
	
    $('#prev_arr, #next_arr')
	.sprites({
		method:'simple',
		duration:400,
		easing:'easeOutQuint',
		hover:true
	})
	
	// slider
	$(".slider").jCarouselLite({
        btnNext:'.next',
        btnPrev:'.prev',
        easing: 'easeOutSine',
        speed: 500,
        visible: 3,
    });
	 
	 
	 $('.slider>ul>li>a>span').css({opacity:0})
    $('.slider>ul>li>a').hover(function()
    {
        $('>span', this).stop().animate({opacity:1}, aniButtonDuration,'easeOutCubic')					   
    }, function(){
        $('>span', this).stop().animate({opacity:0}, aniButtonDuration,'easeOutCubic')						   
    })
	 
	 $('.prev, .next ')
		.sprites({
			method:'simple',
			hover:true
		})
	//end slider
		
        
    $('').each(function(){
        $(this).find('>span').stop().animate({opacity:0},0);
        $(this).hover(function()
        {
            $(this).find('>span').stop().animate({opacity:1}, aniButtonDuration,'easeOutCubic')					   
        }, function(){
        	$(this).find('>span').stop().animate({opacity:0}, aniButtonDuration,'easeOutCubic')						   
        })
    })
	
	
	//follow-icons-------------	 
   $('.follow-icon .img_act').css({opacity:0})
	$('.follow-icon a').hover(function(){
		$(this).find('.img_act').stop().animate({opacity:1})
      $(this).find('p').stop().animate({color:'#000'}, 550, 'easeOutSine')						 
	}, function(){
		$(this).find('.img_act').stop().animate({opacity:0})
      $(this).find('p').stop().animate({color:'#1E1E1E'}, 550, 'easeOutSine')							 
	})


    /////////////////////////////////////////////////////////////////////////// 
    //                           content switch                              //
    ///////////////////////////////////////////////////////////////////////////
    
    var content=$('#content'),
        nav=$('.menu'),
        header=$('header'),
        body=$('body');
    
    $('ul#menu').superfish({
      delay:       700,
      animation:   {height:'show'},
      speed:       300,
      autoArrows:  false,
      dropShadows: false
    });

    $('.submenu_1 a b').css({width:'0px'})
    $('.submenu_1 a').hover(function()
    {
        $(this).find('b').css({width:'0px', left:'0px'}).stop().animate({width:'100%'}, 300,'easeOutCubic');			   
    }, function(){
        $(this).find('b').stop().animate({width:'0px', left:'119px'}, 300,'easeOutCubic');						   
    })
    
    
    nav.navs({
		useHash:true,
        defHash:'#!/page_splash',
		hoverIn:function(li){
		   	  $('>a ',li).css({color:'#000000'});
		   	  $('> a > span ',li).css({display:'block'}).stop().animate({opacity:1}, aniButtonDuration, 'easeOutCubic');
		},
		hoverOut:function(li){
		  if (!li.hasClass('with_ul') || !li.hasClass('sfHover')) {
              $('>a ',li).css({color:'#ffffff'});
		   	  $('> a > span ',li).stop().animate({opacity:0}, aniButtonDuration, 'easeOutCubic', function(){
		   	      $(this).css({display:'none'});
		   	  });
          }
		}				
    })
    
	 
	 $(window).resize(function (){
		 if (h < defMh) {h = defMh}
		 $('body').stop().animate({'minHeight':h})
		});
	
	
     content.tabs({
		preFu:function(_)
        {
            _.li.css({display:'none', top:'620px'});
            _.li.each(function(){
                if($(this).height() < 365){
                    $(this).height(365);
                } else {
                    $(this).height($(this).height()+30)
                }
            })
				
			
		}
		,actFu:function(_)
        {

            if(_.pren == undefined){
                aniDelay = 250;
            } else {
                if(_.n == -1 && _.pren == -1){
                    aniDelay = 250;
                } else {
                    aniDelay = 450;
                }
            }
            
					 
            if(_.n == -1 || _.n == 0){
               content.stop().delay(aniDelay).animate({height:'320px'}, 650,'easeOutCubic');
					header.stop().delay(aniDelay).animate({"padding-top":100}, 650,'easeOutCubic');
               /*body.stop().animate({height:400}, 0,'easeOutCubic');*/
					$(window).trigger('resize');
					 
            } else {
                content.stop().delay(aniDelay).animate({height:_.curr.height()+30}, 650,'easeOutCubic');
					 header.stop().delay(aniDelay).animate({"padding-top":0}, 650,'easeOutCubic');
					 $(window).trigger('resize');
            }
            
        	if(_.curr){
        	   h = parseInt( _.curr.outerHeight(true)+520);
				$(window).trigger('resize');
				_.curr
					.stop()
					.delay(aniDelay).css({display:'block', top:content.height()}).animate({top:'0px'}, 650,'easeOutCubic');
            }
				
            
			if(_.prev){
			    _.prev 
    				.stop()
    				.animate({top:content.height()}, 350,'easeInSine', function(){
    				     $(this).css({display:'none'});
    			     });
            }
           
        }
		
	})
       
    nav.navs(function(n, _)
    {
		content.tabs(n);
	})
 
})