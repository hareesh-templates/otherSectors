$(window).load(function(){
	var sliders = $("#_slider>div"),
		slidNumberNew=0,
		slidNumberOld=0,
		slidAll= $("#_slider>div").length,
		autoPlayState = true,
		anomationStop=false,
		MSIE = ($.browser.msie) && ($.browser.version <= 8);
		
	$(window).bind("hashchange", changeSiteHash);
	changeSiteHash()	
	init()
	function init(){

		sliders.css({"position":"absolute"});
		if(!MSIE){
			sliders.not(sliders.eq(slidNumberNew)).find('.slider_pic').animate({"top":'350px'}, 0)
			//sliders.not(sliders.eq(slidNumberNew)).find('.text1').animate({"top":'-250px'}, 0)
		}else{
			sliders.not(sliders.eq(slidNumberNew)).css({'display':'none'});
		}
        
		anomationStop=true;
		autoPlay();
	}
	function changeSiteHash(){
		if(window.location.hash !="#!/home") {
			autoPlayState=false;
		}
	}
	function autoPlay(){
		setTimeout(temeOut, 3000);
		function temeOut(){
			if(autoPlayState){
				slidNumberOld = slidNumberNew
				slidNumberNew++;
				if(slidNumberNew>slidAll-1){
					slidNumberNew=0;
					autoPlayState = false;
				}
				changeImage();
			}
		}
	}
    ////////////////////////////
   $('.navGall > ul > li').click(
    function(){
        if((anomationStop) && ($(this).index() != slidNumberNew) ){
            var curIndex; 
            curIndex = $(this).index();
            slidNumberOld = slidNumberNew;
            slidNumberNew = curIndex;
            changeImage();
        }
    }
    
)  

    ////////////////////////////
    
	function changeImage(){
		anomationStop=false;
		if(!MSIE){
			//sliders.eq(slidNumberOld).find('.ani_box').animate({"top":'250px'}, 800 , 'easeInOutCubic')
			sliders.eq(slidNumberOld).find('.slider_pic').css({"background":"none"}).animate({"top":'-350px'}, 800 , 'easeInOutCubic')
			//sliders.eq(slidNumberOld).find('.text1').animate({"top":'250px'}, 800 , 'easeInOutCubic')
		
		}else{
			sliders.eq(slidNumberOld).css({'display':'none'});
		}

		if(!MSIE){
			//sliders.eq(slidNumberNew).find('.ani_box').css({'top':'-250px'}).delay(100).animate({"top":'80px'}, 800, 'easeInOutCubic')
			sliders.eq(slidNumberNew).find('.slider_pic').css({"background":"none",'top':'1050px'}).animate({"top":'0px'}, 800, 'easeInOutCubic', function(){anomationStop=true;})
			//sliders.eq(slidNumberNew).find('.text1').css({'top':'-250px'}).delay(100).animate({"top":'80px'}, 800, 'easeInOutCubic')
			
	   }else{
		  sliders.eq(slidNumberNew).css({'display':'block'});
		//	sliders.eq(slidNumberNew).fadeTo(500,1, function(){anomationStop=true;});
            setTimeout(function(){anomationStop=true;}, 100)
		}
 
		autoPlay();
	}

	
// buttons functions    
var menuItems = $('#menu >li'); 
var currentIm = 0;
var lastIm = 0;

navInit();
function navInit(){

if(!MSIE){
$('.navGall > ul >li .pointNav').fadeTo(0, 0, function(){
    $('.navGall > ul > li').eq(0).find('.pointNav').stop().fadeTo(0, 1);
    $('.navGall > ul > li').eq(0).find('.txt_num').stop().animate({color:'#A96F3E'},{duration:100});
} );
}else{
    $('.navGall > ul >li  .pointNav').css({'display':'none'});
    $('.navGall > ul > li').eq(0).find('.pointNav').css({'display':'inline-block'});
}     
    
$('.navGall > ul >li').hover(
    function(){
        if ($(this).index() != currentIm) {
            if(!MSIE){
             $(this).find('.pointNav').stop().fadeTo(500, 1);
				 $(this).find('.txt_num').stop().animate({color:'#A96F3E'},{duration:100})
   
             }else{
                 $(this).find('.pointNav').css({'display':'inline-block'});

             }
        }
    }, function(){
        if ($(this).index() != currentIm) {
             if(!MSIE){
                $(this).find('.pointNav').stop().fadeTo(500, 0);
					 $(this).find('.txt_num').stop().animate({color:'#FFFFFF'},{duration:100})
               
            }else{
                $(this).find('.pointNav').css({'display':'none'});
                      
            }
        }
    }
)

    $('.navGall > ul > li').bind('click',function(e){
        lastIm = currentIm;
        currentIm = $(this).index(); 
        if(!MSIE){
            $('.navGall > ul > li').eq(lastIm).find('.pointNav').stop().fadeTo(500, 0);
            $('.navGall > ul > li').eq(currentIm).find('.pointNav').stop().fadeTo(500, 1);
				
				$('.navGall > ul > li').eq(lastIm).find('.txt_num').stop().animate({color:'#FFFFFF'},{duration:100})
            $('.navGall > ul > li').eq(currentIm).find('.v').stop().animate({color:'#A96F3E'},{duration:100})
       
        }else{
            $('.navGall > ul > li').eq(lastIm).find('.pointNav').css({'display':'none'});
            $('.navGall > ul > li').eq(currentIm).find('.pointNav').css({'display':'inline-block'}); 
        }
    });
}
//end buttons functions
})