<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search results</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
    <meta name="description" content="Your description">
    <meta name="keywords" content="Your keywords">
    <meta name="author" content="Your name">    
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Oleo+Script' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="search/search.js"></script>
    <script src="js/jquery.ui.totop.js" type="text/javascript"></script>
  <!--[if lt IE 8]>
      <div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg"border="0"alt=""/></a></div>  
  <![endif]-->
  <!--[if lt IE 9]>
  	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:700' rel='stylesheet' type='text/css'>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <link rel="stylesheet" href="css/docs.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
  <![endif]-->
</head>

<body>
<!--==============================header=================================-->
<header>
    <div class="container">
        <div class="row">
            <div class="span12 clearfix">
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">
                        <div class="container">
                            <h1 class="brand"><a href="index.html">collaboration</a></h1>
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse_">menu</a>                                                   
                            <div class="nav-collapse nav-collapse_ collapse">
                                <ul class="nav sf-menu">
                                  <li><a href="index.html">Main</a></li>
                                  <li class="sub-menu"><a href="index-1.html">About us</a>
                                    <ul>
                                      <li class="sub-menu"><a href="#">Company</a><em></em>
                                      	<ul>
                                          <li><a href="#">Our advantages</a><em></em></li>
                                          <li><a href="#">Work team</a></li>
                                          <li><a href="#">Testimonials</a></li>
                                        </ul>
                                      </li>
                                      <li><a href="#">Management Consulting</a></li>
                                      <li><a href="#">Market Assessment</a></li>
                                      <li><a href="#">Awards</a></li>
                                      <li><a href="#">Regulatory Support</a></li>
                                      <li><a href="#">Support</a></li>
                                      <li><a href="#">Data Warehousing</a></li>
                                    </ul>
                                  </li>
                                  <li><a href="index-2.html">Services</a></li>
                                  <li><a href="index-3.html">Projects</a></li>
                                  <li><a href="index-4.html">Blog</a></li>
                                  <li><a href="index-5.html">Contacts</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<section id="content">
  <div class="container">
    <div class="row">
    	<div class="span12">
            <h4>Search result:</h4>
            <div id="search-results"></div>
		</div>  
    </div>        
  </div>
</section>
<aside>
  <div class="container">
    <div class="row">
      <div class="span3"> 
      	<h4 class="indent-2">About us</h4>
        <ul class="list">
        	<li><a href="#">Market Research</a></li>
            <li><a href="#">Online Banking</a></li>
            <li><a href="#">Financial Services</a></li>
            <li><a href="#">Client Network Solutions</a></li>
            <li class="bot-0"><a href="#">Business Help</a></li>
        </ul>
      </div>
      <div class="span3"> 
      	<h4 class="indent-2">popular</h4>
        <ul class="list">
        	<li><a href="#">Solutions & Training</a></li>
            <li><a href="#">Affiliate Program</a></li>
            <li><a href="#">Production</a></li>
            <li><a href="#">Risk Management</a></li>
            <li class="bot-0"><a href="#">Consultation</a></li>
        </ul>
      </div>
      <div class="span3"> 
      	<h4 class="indent-2">links</h4>
        <ul class="list">
        	<li><a href="#">Strategies</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Recent Issues</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">Solutions</a></li>
            <li><a href="#">Business Help</a></li>
            <li class="bot-0"><a href="#">Contacts</a></li>
        </ul>
      </div>
      <div class="span3"> 
      	<h4 class="indent-2">follow us</h4>
        <ul class="social-list">
        	<li><a href="#"><img src="img/icon-1.png" alt=""><span>RSS</span></a></li>
            <li><a href="#"><img src="img/icon-2.png" alt=""><span>Twitter</span></a></li>
            <li><a href="#"><img src="img/icon-3.png" alt=""><span>Flickr</span></a></li>
            <li class="bot-0"><a href="#"><img src="img/icon-4.png" alt=""><span>Facebook</span></a></li>
        </ul>
      </div>
    </div>
  </div>
 </aside>     
<footer>
	<div class="container">
        <div class="row">
          <div class="span12">Collaboration &copy; 2012 • <a href="index-6.html">Privacy Policy</a></div>
        </div>
    </div>
</footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>