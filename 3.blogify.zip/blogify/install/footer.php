 <div class="copy_layout login register">
      <p>Copyright &copy; 2016 eBlog. All Rights Reserved | Design by <a href="http://facebook.com/hillsoftsnetwork" target="_blank">Hillsofts</a> </p>
   </div>
</body>
</html>
