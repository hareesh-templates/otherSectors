<?php
include('includes/connection.php');
include('includes1/header1.php');
?>

<aside id="fh5co-hero" class="js-fullheight">
<div class="flexslider js-fullheight">
<ul class="slides">
<li style="background-image: url(studdesign/images/home.jpg);">
<div class="overlay-gradient"></div>
<div class="container-fluid">
<div class="row">
<div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text slider-text-bg">
<div class="slider-text-inner">
<h1>Welcome Student!</h1>
<h2>Need a Book?</h2>
</div>
</div>
</div>
</div>
</li>
		
<li style="background-image: url(studdesign/images/2015.jpg);">
<div class="overlay-gradient"></div>
<div class="container-fluids">
<div class="row">
<div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text slider-text-bg">
<div class="slider-text-inner">
<h1>Please Click the Transaction Page for Borrowing Books!</h1>
<h2>Thank You!</h2>
</div>
</div>
</div>
</div>
</li>		   	
</ul>
</div>
</aside>

<?php
include('includes1/footer1.php');
?>	