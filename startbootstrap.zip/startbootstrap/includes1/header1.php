<?php
require('session1.php');
confirm_logged_in();
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>LMS Student - Fiction Category</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
<meta name="author" content="freehtml5.co" />

<!-- 
//////////////////////////////////////////////////////

FREE HTML5 TEMPLATE 
DESIGNED & DEVELOPED by FreeHTML5.co
		
Website: 		http://freehtml5.co/
Email: 			info@freehtml5.co
Twitter: 		http://twitter.com/fh5co
Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////

	 -->

<!-- Facebook and Twitter integration -->
<meta property="og:title" content=""/>
<meta property="og:image" content=""/>
<meta property="og:url" content=""/>
<meta property="og:site_name" content=""/>
<meta property="og:description" content=""/>
<meta name="twitter:title" content="" />
<meta name="twitter:image" content="" />
<meta name="twitter:url" content="" />
<meta name="twitter:card" content="" />

<!-- <link href="https://fonts1.googleapis.com/css1?family=Work+Sans:300,400,500,700,800" rel="stylesheet">	 -->
<link href="https://fonts1.googleapis.com/css1?family=Space+Mono" rel="stylesheet">
<!-- Animate.css1 -->
<link rel="stylesheet" href="studdesign/css/animate.css">
<!-- Icomoon Icon fonts1-->
<link rel="stylesheet" href="studdesign/css/icomoon.css">
<!-- Bootstrap  -->
<link rel="stylesheet" href="studdesign/css/bootstrap.css">
<!-- Magnific Popup -->
<link rel="stylesheet" href="studdesign/css/magnific-popup.css">
<!-- Flexslider  -->
<link rel="stylesheet" href="studdesign/css/flexslider.css">
<!-- Theme style  -->
<link rel="stylesheet" href="studdesign/css/style.css">
<!-- Modernizr js1 -->
<script src="studdesign/js/modernizr-2.6.2.min.js"></script>
<!-- FOR IE9 below -->
<!--[if lt IE 9]>
<script src="js1/respond.min.js1"></script>
<![endif]-->

</head>


<?php include'navbar1.php'; ?>