<footer id="fh5co-footer" role="contentinfo">

<div class="row copyright">
<div class="col-md-12 text-center">
<p>
<small class="block">&copy; 2019 Books Borrower. All Rights Reserved.</small>
</p>
</div>
</div>
</footer>

<div class="gototop js-top">
<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
</div>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
<button class="close" type="button" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>

<div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
<div class="modal-footer">
<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
<a class="btn btn-primary" href="logouttransaction1.php">Logout</a>
</div>
</div>
</div>
</div>


	
<!-- jQuery -->
<script src="studdesign/js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="studdesign/js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="studdesign/js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="studdesign/js/jquery.waypoints.min.js"></script>
<!-- Flexslider -->
<script src="studdesign/js/jquery.flexslider-min.js"></script>
<!-- Magnific Popup -->
<script src="studdesign/js/jquery.magnific-popup.min.js"></script>
<script src="studdesign/js/magnific-popup-options.js"></script>
<!-- Main -->
<script src="studdesign/js/main.js"></script>

</body>
</html>

