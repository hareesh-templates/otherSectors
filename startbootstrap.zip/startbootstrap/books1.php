<?php include('includes/connection.php'); ?>
<?php include('includes1/header1.php');  ?>

<div>
<img src="studdesign/images/LOVEINWAR.png" style="float: left; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkonceuponatime.php"> Love in War </a></li>
<img src="studdesign/images/MANDYMAN.png" style="float: left; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkmandyman.php">Mandy Man</a></li>
<img src="studdesign/images/ONCEUPONATIME.png" style="float: left; width: 8.8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkonceuponatime.php">Once Upon a Time</a></li>
<img src="studdesign/images/ABNKKPBNPA.png" style="float: left; width: 8.3%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkabnkkpbsnpa.php">ABNKKPBNPA</a></li>
<img src="studdesign/images/ANGELSEYE.png" style="float: left; width: 8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkangelseye.php">Angels Eye</a></li>
<img src="studdesign/images/TEMPORARY.png" style="float: left; width: 8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bktemporary.php">Temporary</a></li>
<img src="studdesign/images/EVERLASTING.png" style="float: left; width: 8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkeverlasting.php">Everlasting</a></li>
<img src="studdesign/images/MATCHMAKER.png" style="float: left; width: 8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkmatchmaker.php">Match Maker</a></li>
<img src="studdesign/images/BEYONDLIES.png" style="float: left; width: 8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkbeyondlies.php">Beyond Lies</a></li>
<img src="studdesign/images/UNDEFINEDLOVE.png" style="float: left; width: 8.3%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkundefinedlove.php">Undefined Love</a></li>
</div>
<br><br><br><br><br>
<div>
<img src="studdesign/images/LIVINGALIE.png" style="float: left; width: 7.6%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bklivingalie.php">Living a Lie</a></li>
<img src="studdesign/images/ANICEPLACE.png" style="float: left; width: 7.5%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkaniceplace.php">A Nice Place</a></li>
<img src="studdesign/images/CLINTON.png" style="float: left; width: 7.9%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkclinton.php">Clinton</a></li>
<img src="studdesign/images/MANANDWOMAN.png" style="float: left; width: 7.8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkmanandwoman.php">Man and Woman</a></li>
<img src="studdesign/images/UNTILITSOVER.png" style="float: left; width: 7.8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkuntilitsover.php">Until it's Over</a></li>
<img src="studdesign/images/THELIGHTNING.png" style="float: left; width: 7.8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkthelightning.php">The Lightning</a></li>
<img src="studdesign/images/MEMORABLEONE.png" style="float: left; width: 7.8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkmemorableone.php">Memorable One</a></li>
<img src="studdesign/images/STANDINGALONE.png" style="float: left; width: 7.3%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkstandingalone.php">Standing Alone</a></li>
<img src="studdesign/images/ITISNTAGAME.png" style="float: left; width: 8.1%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkitisntagame.php">It isn't a Game</a></li>
<img src="studdesign/images/DAWN.png" style="float: left; width: 7.6%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkdawn.php">Dawn</a></li>
</div>
<br><br><br><br><br><br>
<div>
<img src="studdesign/images/YESORNO.png" style="float: left; width: 8.4%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkyesorno.php">Yes or No?</a></li>
<img src="studdesign/images/FANTASTICFRIENDSHIP.png" style="float: left; width: 7.2%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkfantasticfriendship.php">Fantastic Friendship</a></li>
<img src="studdesign/images/TAKEARISK.png" style="float: left; width: 7.3%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bktakearisk.php">Take a Risk</a></li>
<img src="studdesign/images/UNDERGROUND.png" style="float: left; width: 7.7%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkunderground.php">Underground</a></li>
<img src="studdesign/images/WINORLOSE.png" style="float: left; width: 7.8%; margin-right: 1%; margin-bottom: 0.5em;">
<li><a href="bkwinorlose.php">Win or Lose?</a></li>
</div>

<?php
include('includes1/footer1.php');
      ?>
