<?php include 'header.php'; ?>
<script>  
function validateform(){  
var file=document.myform.file.value;  
  
if (file==null || file==""){  
  alert("Please attach the file.");  
  return false;  
}  
}  
</script>  
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center" style=" background-image: url('assets/img/1.jpg');background-repeat: no-repeat;background-size: cover;">
 
    <div class="container">
      <div class="row">
  
        <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1" style="padding-top: 50px!important;">
         <!--  <h1 class="head1">Work In The USA AS A Speciality Worker</h1> -->
         <!--  <h2>Live And Work In the USA, A Route To A Green Card, Stay With Your Dependent Spouse & Children</h2> -->
          <!-- <a href="#about" class="btn-get-started scrollto">Get Started</a> -->

          


             <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">

      <!--Controls-->
      <div class="controls-top">
        <a class="btn-floating" href="#multi-item-example" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
        <a class="btn-floating" href="#multi-item-example" data-slide="next"><i class="fa fa-chevron-right"></i></a>
      </div>
      <!--/.Controls-->

      <!--Indicators-->
      <ol class="carousel-indicators" style="bottom: -50px!important;">
        <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
        <li data-target="#multi-item-example" data-slide-to="1"></li>
        <li data-target="#multi-item-example" data-slide-to="2"></li>
        <li data-target="#multi-item-example" data-slide-to="3"></li>
      </ol>
      <!--/.Indicators-->

      <!--Slides-->
      <div class="carousel-inner" role="listbox">

        <!--First slide-->
        <div class="carousel-item active">

          <div class="row">
            <div class="col-md-2">
             <!--  <div class="card mb-2">
                <img class="card-img-top" src="assets/img/11.jpg" alt="Card image cap">
                
              </div> -->
            </div>

            <div class="col-md-8 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img class="card-img-top" src="adminpanel/assets/img/<?php echo $slider_image1; ?>"
                  alt="Card image cap">
                
              </div>
            </div>

            <div class="col-md-2 clearfix d-none d-md-block">
             <!--  <div class="card mb-2">
                <img class="card-img-top" src="assets/img/13.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>
          </div>

        </div>
        <!--/.First slide-->

        <!--Second slide-->
        <div class="carousel-item">

          <div class="row">
            <div class="col-md-2">
            <!--   <div class="card mb-2">
                <img class="card-img-top" src="assets/img/14.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>

            <div class="col-md-8 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img class="card-img-top" src="adminpanel/assets/img/<?php echo $slider_image2; ?>"
                  alt="Card image cap">
                
              </div>
            </div>

            <div class="col-md-2 clearfix d-none d-md-block">
             <!--  <div class="card mb-2">
                <img class="card-img-top" src="assets/img/16.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>
          </div>

        </div>
        <!--/.Second slide-->

        <!--Third slide-->
        <div class="carousel-item">

          <div class="row">
            <div class="col-md-2">
             <!--  <div class="card mb-2">
                <img class="card-img-top" src="assets/img/17.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>

            <div class="col-md-8 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img class="card-img-top" src="adminpanel/assets/img/<?php echo $slider_image3; ?>"
                  alt="Card image cap">
                
              </div>
            </div>

            <div class="col-md-2 clearfix d-none d-md-block">
             <!--  <div class="card mb-2">
                <img class="card-img-top" src="assets/img/19.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>
          </div>

        </div>
        <!--/.Third slide-->
         <div class="carousel-item">

          <div class="row">
            <div class="col-md-2">
            <!--   <div class="card mb-2">
                <img class="card-img-top" src="assets/img/14.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>

            <div class="col-md-8 clearfix d-none d-md-block">
              <div class="card mb-2">
                <img class="card-img-top" src="adminpanel/assets/img/<?php echo $slider_image4; ?>"
                  alt="Card image cap">
                
              </div>
            </div>

            <div class="col-md-2 clearfix d-none d-md-block">
             <!--  <div class="card mb-2">
                <img class="card-img-top" src="assets/img/16.jpg"
                  alt="Card image cap">
                
              </div> -->
            </div>
          </div>

        </div>
      </div>
      <!--/.Slides-->

    </div>








        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img">
          <div class="panel panel-primary enqform">
     
      <div class="panel-body">
            <form action="upload.php" method="post" enctype="multipart/form-data" name="myform" onsubmit="return validateform()">
              <fieldset>
  <legend style="text-align: center;color: #fff;"><b class="bbb">H1B Transfer</b><br><b class="bbb" style="    font-size: smaller;">(CAP Exempt)</b></legend>
   <div class="form-group">
    <input type="text" class="form-control" id="" aria-describedby="emailHelp" placeholder="Ful name" name="fullname">
  </div>
  <div class="form-group">
    <input type="email" class="form-control" id="" aria-describedby="emailHelp" placeholder="Email" name="email">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" id="" placeholder="Mobile" name="mobile">
  </div>
  <div class="form-group">
    <select class="form-control" name="country">
      <option value="">Select Country</option>
      <option value="US">US</option>
      <option value="UK">UK</option>
      <option value="Australia">Australia</option>
      <option value="India">India</option>
      <option value="Others">Others</option>
    </select>
  </div>
    <div class="form-group">
    <select class="form-control" name="visatype">
      <option value="H1B">H1B</option>
      <option value="Fresh H1B">Fresh H1B</option>
      <option value="H1B Transfer">H1B Transfer</option>
      <option value="Others">Others</option>
    </select>
  </div>
  <div class="form-group">
  
    <textarea name="comments" placeholder="Comment" class="form-control"></textarea>
  </div>
  <div class="form-group">
    <input type="file" class="form-control" id="" name="file" style="background-color: #fff0; border: 0px;color: #fff;
}">
  </div>
  
  <h1 style="text-align: center;"><button name="upload" type="submit" class="btn btn-primary" style="background-color: #59a84f;border-color: #59a84f;">Submit</button></h1>
</fieldset>
</form>
</div>
    </div>

        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">
     <section id="aboutus" class="services section-bg" style='display:none;'>
      <div class="container">

        <div class="section-title" data-aos="fade-up">
         <!--  <h2>Steps for H1B Visa</h2> -->
          <h2>THEA GLOBAL OVRERSEAS CONSULTANCY</h2>
          <!-- <p>Requirements & Specifications</p> -->
        </div>
         <p data-aos="fade-up" data-aos-delay="100">
                <p  data-aos="fade-up" data-aos-delay="100">THEA GLOBAL OVRERSEAS CONSULTANCY (India)  
Thea Global Overseas Consultancy assists people who desire to relocate abroad to pursue their education and build a better life for themselves.</p>
               <p  data-aos="fade-up" data-aos-delay="100">The Global Overseas Consultancy is a company that handles the entire application procedure for overseas education applicants like USA, UK, CANNADA, AUSTRALIA, GERMANY…etc.</p>
               <p  data-aos="fade-up" data-aos-delay="100">Thea Global Overseas consultancy offers advice to parents and students about studying abroad, also hold awareness events at colleges and universities.
Thea global will be given the training to English tests like IELTS, TOEFL, DUOLINGO,PTE,GMAT .</p>
               <ul>
              <li>Thea Global will assist in selecting programmes and universities of the highest calibre.</li>
 <li> Thea Global will offer comprehensive application support, help with financial documentation, and will aid in obtaining the Admission conformation (I 20) from universities. </li> 
 <li> Mock interviews are conducted prior to the visa interview to avoid the inexperienced applicants, and Thea Global will assist with booking visa slots and handling the visa interviews after receiving the (I20).</li>
 <li> Thea global also provided the education loans through private companies and banks from which is under the protection of reserve bank
Additionally, Thea Global offered the student loans through banks and private businesses that are safeguarded by the reserve bank.</li>
            </ul>
      </div>
    </section>
    <!-- ======= About Section ======= -->
    <section id="aboutus1" class="about">
      <div class="container" style="margin-top: -30px;">

        <div class="row justify-content-between">
       <!--    <div class="col-lg-5 d-flex align-items-center justify-content-center about-img">
            <img src="assets/img/2.png" class="img-fluid" alt="" data-aos="zoom-in" style="height: 220px;">
          </div> -->
          <div class="col-lg-12 pt-5 pt-lg-0">
            <div class="section-title" data-aos="fade-up">
            <h3 data-aos="fade-up" style="background-color: deepskyblue;
            font-family: Calibri;
    font-weight: 700;
    font-size: 34px;
    color: #fff;
    border-radius: 20px;
    padding: 5px;
    border: 1px solid #509d4b;"><marquee style="text-align: center;"> <?php echo $heading1; ?></marquee></h3>
    <h3 style="margin-top: 15px;">About Us</h3>
          </div>
           <p data-aos="fade-up" data-aos-delay="100">
                <p  data-aos="fade-up" data-aos-delay="100">THEA GLOBAL OVRERSEAS CONSULTANCY (India)  
Thea Global Overseas Consultancy assists people who desire to relocate abroad to pursue their education and build a better life for themselves.</p>
               <p  data-aos="fade-up" data-aos-delay="100">The Global Overseas Consultancy is a company that handles the entire application procedure for overseas education applicants like USA, UK, CANNADA, AUSTRALIA, GERMANY…etc.</p>
               <p  data-aos="fade-up" data-aos-delay="100">Thea Global Overseas consultancy offers advice to parents and students about studying abroad, also hold awareness events at colleges and universities.
Thea global will be given the training to English tests like IELTS, TOEFL, DUOLINGO,PTE,GMAT .</p>
               <ul>
              <li>Thea Global will assist in selecting programmes and universities of the highest calibre.</li>
 <li> Thea Global will offer comprehensive application support, help with financial documentation, and will aid in obtaining the Admission conformation (I 20) from universities. </li> 
 <li> Mock interviews are conducted prior to the visa interview to avoid the inexperienced applicants, and Thea Global will assist with booking visa slots and handling the visa interviews after receiving the (I20).</li>
 <li> Thea global also provided the education loans through private companies and banks from which is under the protection of reserve bank
Additionally, Thea Global offered the student loans through banks and private businesses that are safeguarded by the reserve bank.</li>
            </ul>
            <p data-aos="fade-up" data-aos-delay="100">
              <?php echo $content1; ?>
            </p>
            <div class="row">
              <div class="col-md-12" data-aos="fade-up" data-aos-delay="100">
               <!--  <i class="bx bx-receipt"></i> -->
                <h4 style="color: #4285F4"><?php echo $heading2; ?></h4>
                <p>
          <?php echo $content2; ?></p>
              </div>
              </div>
             
            

             <div class="row">
              <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
               <!--  <i class="bx bx-receipt"></i> -->
                <h4 style="color: #F4B400"><?php echo $heading4; ?></h4>
                <p>

 <?php echo $content4; ?></p>
              </div>
               <div class="col-md-6" data-aos="fade-up" data-aos-delay="200">
               <!--  <i class="bx bx-cube-alt"></i> -->
                <h4 style="color: #DB4437"><?php echo $heading3; ?></h4>
                <p>
 <?php echo $content3; ?></p>
              </div>
             
            </div>

             <div class="row">
                  <div class="col-md-6" data-aos="fade-up" data-aos-delay="200">
               <!--  <i class="bx bx-cube-alt"></i> -->
                <h4 style="color: #4285F4"><?php echo $heading5; ?></h4>
                <p>

 <?php echo $content5; ?></p>
              </div>
              <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
               <!--  <i class="bx bx-receipt"></i> -->
                <h4 style="color: #0F9D58"><?php echo $heading6; ?>
</h4>
                <p>
 <?php echo $content6; ?></p>
              </div>
             
            </div>
             <div class="row">
                  <div class="col-md-12" data-aos="fade-up" data-aos-delay="200">
                <!-- <i class="bx bx-cube-alt"></i> -->
                <h4 style="color: #DB4437"><?php echo $heading7; ?></h4>
                <p>

 <?php echo $content7; ?></p>
              </div>
             </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
    
    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
         <!--  <h2>Steps for H1B Visa</h2> -->
          <h2>Services & Specifications</h2>
          <!-- <p>Requirements & Specifications</p> -->
        </div>

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><!-- <i class="bx bxl-dribbble"></i> --></div>
              <h4 class="title" ><a href="" style=" text-shadow: 1px 1px 2px black, 0 0 25px #fefeff, 0 0 5px #c55ad2;
    color: yellow;"><?php echo $heading8; ?></a></h4>
              <p class="description"><?php echo $content8; ?></p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><!-- <i class="bx bx-file"></i> --></div>
              <h4 class="title"><a href="" style="text-shadow: 1px 1px 2px black, 0 0 25px #fefeff, 0 0 5px #c55ad2;
    color: yellow;"><?php echo $heading9; ?></a></h4>
              <p class="description"><?php echo $content9; ?></p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><!-- <i class="bx bx-tachometer"></i> --></div>
              <h4 class="title" ><a href="" style="text-shadow: 1px 1px 2px black, 0 0 25px #fefeff, 0 0 5px #c55ad2;
    color: yellow;"><?php echo $heading10; ?></a></h4>
              <p class="description"><?php echo $content10; ?></p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><!-- <i class="bx bx-world"></i> --></div>
              <h4 class="title"><a href=""  style="text-shadow: 1px 1px 2px black, 0 0 25px #fefeff, 0 0 5px #c55ad2;
    color: yellow;"><?php echo $heading11; ?></a></h4>
              <p class="description"><?php echo $content11; ?></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

      <section id="h1btransfer" class="services section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
         <!--  <h2>Steps for H1B Visa</h2> -->
          <h2>What is the H1-B Visa Transfer?</h2>
          <!-- <p>Requirements & Specifications</p> -->
        </div>
         <p data-aos="fade-up" data-aos-delay="100">
                <p  data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">The H1B visa is a US non-immigrant visa in the work visa USA category. Within the work visa category, the H-1 visa is for people who have specialty occupations. This means that they have completed advanced education degrees or have extensive training. The most popular type of the H-1 visa is the H1B or sponsorship visa.</p>
               <p  data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">The H1B visa allows people to work in the U.S temporarily, so within a specified period of time. The process of getting an H1B visa is initiated by the employer. This means that you have to find a job and the employer will agree to sponsor you for the U.S government.</p>
               <p  data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">When you get to the U.S on an H1B visa you have already found a job, and you will work for a certain employer. However, for different reasons, people sometimes want to change their employer. This is where the H1B visa transfer process begins, which is detailed below.</p>
              
                <h5>What is the H1B Transfer?</h5>
              
              <p data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">H1B visa holders can change their employer while in the US under a process which is known as the H1B transfer. To be able to apply for an H1B transfer, they must first accept the new job offer is that you still have a valid H1B visa. They can then initiate the H1B transfer status, which could take several months.</p>
              <h5>H1B Transfer Process</h5>
              <p data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">The H1B transfer process is similar to applying for the H1B visa initially. One difference between the initial H1B visa and the H1B visa transfer is the lack of a visa cap. The H1B visa has a cap of 65,000 people annually that can get this visa. But the H1B transfer has no visa cap. So if you already have an H1B visa, you do not go through the H1B lottery.  This means that you do not count towards the visa cap to get the transfer.</p>
              <p data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">The process of applying for an H1B transfer visa is as follows:</p>
              <h5>Get a new employment offer</h5>
              <p data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">If you are currently working for employer A, you will need a job offer from employer B in the U.S to initiate the H1B transfer visa process. You cannot transfer to another employer if you have not yet been offered the job.</p>
              <h5>The employer needs to get a Labor Condition Application (LCA) from the Department of Labor (DOL)</h5>
              <p data-aos="fade-up" data-aos-delay="100" style="font-size: 15px;color: #5a6570;">U.S employers are not allowed to hire foreign workers without an LCA certification. Employers can get this document from the U.S Department of Labor. Employers apply for this certification by filing Form ETA9035E. This certification guarantees foreign workers that the U.S employer will treat them fairly by paying a full wage. It also states that they will get a good work environment. In addition, it tells the U.S government that the employer hires legally admitted foreign workers.</p>
 
          
      </div>
    </section>

    <!-- ======= Portfolio Section ======= -->
   <section id="eligibility" class="eligibility section-bg" style="display:none;">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Documents Required</h2>
         <!--  <p>Documents Required</p> -->
        </div>
        <div class="row col-md-12">
        <div class="row col-md-9">
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
          <div class="icon-box">
            <ul class="docs">
          <li>  Mandate bachelor degree</li>
          <li>  Relevant licence required</li>
          <li>  Relevant expeience if required</li>
            </ul>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="200">
          <div class="icon-box">
          <h4 class="title"><a href="" style=""><b class="bbb">Duration of Stay</b></a></h4>
          <ul class="docs2">
          <li style="margin-left: -35px;">  Three Years, Extendable to Six Years</li></ul>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="300">
             <div class="icon-box">
          <h4 class="title"><a href="" style=""><b class="bbb">Lottery System</b></a></h4>
          <ul class="docs2">
          <li style="margin-left: -35px;">  From April 1,till October 1 is the fiscal for the withdraw of lottery</li>
        </ul>
            </div>
          </div>

          <!-- <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
          <h4 class="title"><a href="" style=""><b>Visa Cost</b></a></h4>
          <p>An H-1B Visa (or H-1B transfer) will cost you around $5000 (including government fees)</p>
            </div>
          </div> -->

           <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
          <h4 class="title"><a href="" style=""><b class="bbb">Family & Dependents</b></a></h4>
          <ul class="docs2">
          <li style="margin-left: -35px;">  It's a family visa and the depends hold H4 visa</li>
        </ul>
            </div>
          </div>

           <div class="col-md-6 col-lg-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
          <h4 class="title"><a href="" style=""><b class="bbb">Documents Required</b></a></h4>
          <ul class="docs"> 
            <li>  Valid Passport</li>
          <li>  One Photograph</li>
          <li>  Form DS-160</li>
          <li>  Visa Fees</li>
          <li>  Original Interview Appointment Letter and One Copy</li>
          <li>  I-127 Petition Receipt Number printed on approved Form I-129 petition and copy of your Form I-797 approval.</li><ul>
            </div>
          </div>

        </div>
         <div class="row col-md-3">
          <img src="assets/img/4.png">
         </div>
       
      </div>
    </div>
    </section>

    <!-- ======= F.A.Q Section ======= -->
    <section id="portfolio" class="faq section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Frequently Asked Questions</h2>
         <!--  <p>Frequently Asked Questions</p> -->
        </div>

        <ul class="faq-list">

          <li data-aos="fade-up" data-aos-delay="100">
            <a data-toggle="collapse" class="" href="#faq1"><?php echo $heading12; ?><i class="icofont-simple-up"></i></a>
            <div id="faq1" class="collapse show" data-parent=".faq-list">
              <p>
                <?php echo $content12; ?>
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="200">
            <a data-toggle="collapse" href="#faq2" class="collapsed"><?php echo $heading13; ?><i class="icofont-simple-up"></i></a>
            <div id="faq2" class="collapse" data-parent=".faq-list">
              <p>
                <?php echo $content13; ?>
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="300">
            <a data-toggle="collapse" href="#faq3" class="collapsed"><?php echo $heading14; ?><i class="icofont-simple-up"></i></a>
            <div id="faq3" class="collapse" data-parent=".faq-list">
              <p>
                <?php echo $content14; ?>
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="400">
            <a data-toggle="collapse" href="#faq4" class="collapsed"><?php echo $heading15; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq4" class="collapse" data-parent=".faq-list">
              <p>
                <?php echo $content15; ?>
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="500">
            <a data-toggle="collapse" href="#faq5" class="collapsed"><?php echo $heading16; ?><i class="icofont-simple-up"></i></a>
            <div id="faq5" class="collapse" data-parent=".faq-list">
              <p>
                <?php echo $content16; ?>
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="600">
            <a data-toggle="collapse" href="#faq6" class="collapsed"><?php echo $heading17; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq6" class="collapse" data-parent=".faq-list">
              <p>
               <?php echo $content17; ?>
              </p>
            </div>
          </li>

            <li data-aos="fade-up" data-aos-delay="700">
            <a data-toggle="collapse" href="#faq7" class="collapsed"><?php echo $faqheading18; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq7" class="collapse" data-parent=".faq-list">
              <p>
               <?php echo $faqcontent18; ?>
              </p>
            </div>
          </li>
            <li data-aos="fade-up" data-aos-delay="800">
            <a data-toggle="collapse" href="#faq8" class="collapsed"><?php echo $faqheading19; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq8" class="collapse" data-parent=".faq-list">
              <p>
               <?php echo $faqcontent19; ?>
              </p>
            </div>
          </li>
             <li data-aos="fade-up" data-aos-delay="900">
            <a data-toggle="collapse" href="#faq9" class="collapsed"><?php echo $faqheading20; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq9" class="collapse" data-parent=".faq-list">
              <p>
               <?php echo $faqcontent20; ?>
              </p>
            </div>
          </li>
           <li data-aos="fade-up" data-aos-delay="1000">
            <a data-toggle="collapse" href="#faq10" class="collapsed"><?php echo $faqheading21; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq10" class="collapse" data-parent=".faq-list">
              <p>
               <?php echo $faqcontent21; ?>
              </p>
            </div>
          </li>
            <li data-aos="fade-up" data-aos-delay="1100">
            <a data-toggle="collapse" href="#faq11" class="collapsed"><?php echo $faqheading22; ?> <i class="icofont-simple-up"></i></a>
            <div id="faq11" class="collapse" data-parent=".faq-list">
              <p>
               <?php echo $faqcontent22; ?>
              </p>
            </div>
          </li>

        </ul>

      </div>
    </section><!-- End F.A.Q Section -->

    <!-- ======= Team Section ======= -->
   

    <!-- ======= Clients Section ======= -->
    

    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Contact Us</h2>
          
        </div>

        <div class="row">

          <div class="col-lg-5 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Corporate Office:</h4>
                <p><?php echo $content21; ?></p>
              </div>

            <!--   <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p>info@example.com</p>
              </div>-->

              <div class="phone">
                <!-- <i class="icofont-phone"></i> -->
                <h4>Call:</h4>
                <p><img src="assets/img/6.png" style="height: 20px;" class="">&nbsp;US : <?php echo $content19; ?><br><img src="assets/img/6.gif" style="height: 20px;" class="">&nbsp;IND : <?php echo $content18; ?></p>
                <h4>Mail:</h4>
                <p><img src="assets/img/3.png" style="height: 20px;" class="blink-image">&nbsp;<?php echo $content20; ?></p>
              </div> 
                <!-- <div class="mail">
                <i class="icofont-envelope"></i>
                <h4>Mail:</h4>
                <p><img src="assets/img/3.png" style="height: 20px;">&nbsp;<b>info@lokah.co.in</p>
              </div> --> 
             
              <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe> -->
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30439.42615431954!2d78.37792307081041!3d17.51093725942139!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb91e2aeecd729%3A0x1c22c4ec8a280953!2sVijetha%20Super%20market!5e0!3m2!1sen!2sin!4v1613272132504!5m2!1sen!2sin"  style="border:0; width: 100%; height: 450px;" allowfullscreen></iframe>
          </div>

        </div>

      </div>
    </section><!-- End Contact Us Section -->

  </main><!-- End #main -->

 <?php include 'footer.php'; ?>