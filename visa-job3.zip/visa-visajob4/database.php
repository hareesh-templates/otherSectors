<?php
$servername='localhost';
$username='eswarigr_lokah';
$password='eswarigr_lokah';
$dbname = "eswarigr_lokah";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
?>