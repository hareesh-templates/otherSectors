<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>THEA Global -  H1B Visa Transfer to USA, CANADA from INDIA | H1B Visa Sponsor</title>
  <meta name="description" content="The dream of USA employment, Find the Best visa Consultant in India for H1B VISA TRANSFER, H1B VISA SPONSOR.
We pretty much invented the H1 visas for India, and have been in the business of consulting and H1B visas. In the year 2000, it made a lot of sense for us to extend our horizons to other Visas and Immigration Services, and expand our expertise towards 'greener' pastures like Canada, USA.">
  <meta name="keywords" content="H1b visa  transfer, H1b visa sponsor, h1b visa transfer to usa from india, Best H1B visa consultants in India, H1B visa transfer from India, H1B visa sponsorship from India, H1B visa sponsors consultants in India, h1b visa transfer jobs in usa, H1B visa transfer process, h1b visa transfer jobs in usa.">
  <!-- Favicons -->
   <link href="assets/img/favlogo.jpeg" rel="icon">
  <!--<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="http://lokah.co.in/ " rel="canonical"/>
  <script type="application/ld+json">
         { 
         "@context" : "http://schema.org",
         "@type" : "Organization",
         "name" : "lokah",
         "url" : "http://lokah.co.in/",
         "logo": "http://lokah.co.in/assets/img/40205-logo-with-font-gay.png",
         "sameAs" : [ 
         "https://www.facebook.com/LokahH1Bvisa",
         "https://twitter.com/H1bLokah",
         "https://www.instagram.com/lokahh1b/",
         "https://www.linkedin.com/company/lokah-h1b-visa/",
         "https://lokahh1bvisa.blogspot.com/"
         ]
         }
</script>
<meta name="google-site-verification" content="l0ujFcgc0GigHE9Vth9H5gt1_HDnjHakcO4IDRo9LoI" />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-K2KWB1N897"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-K2KWB1N897');
</script>
  <!-- =======================================================
  * Template Name: Ninestars - v2.0.0
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style type="text/css">
    .nav-menu .get-started a {
   /* background: #eb5d1e;*/
    color: #fff;
    border-radius: 50px;
    margin: 8px 1px;
    padding: 0px 4px;
}
.enqform{
      background-color: #00000080;
    padding: 5px;
    border-radius: 25px;
  }
  .docs {
  list-style: none;
  font-size: 15px;
    color: #5a6570;
}
 .docs2 {
  list-style: none;
  font-size: 15px;
    color: #5a6570;
}
  .docs li:before {
  content: '✓';
}
.docs2 li::before {
  content: '▶';
}
.title a{
    font-size: 20px;
    font-weight: 700;
    margin-top: 5px;
    color: #7a6960;
  }
  @-moz-keyframes blink {
    0% {
        opacity:1;
    }
    50% {
        opacity:0;
    }
    100% {
        opacity:1;
    }
} 

@-webkit-keyframes blink {
    0% {
        opacity:1;
    }
    50% {
        opacity:0;
    }
    100% {
        opacity:1;
    }
}
/* IE */
@-ms-keyframes blink {
    0% {
        opacity:1;
    }
    50% {
        opacity:0;
    }
    100% {
        opacity:1;
    }
} 
/* Opera and prob css3 final iteration */
@keyframes blink {
    0% {
        opacity:1;
    }
    50% {
        opacity:0;
    }
    100% {
        opacity:1;
    }
} 
.blink-image {
    -moz-animation: blink normal 2s infinite ease-in-out; /* Firefox */
    -webkit-animation: blink normal 2s infinite ease-in-out; /* Webkit */
    -ms-animation: blink normal 2s infinite ease-in-out; /* IE */
    animation: blink normal 2s infinite ease-in-out; /* Opera and prob css3 final iteration */
}
.bbb{
      text-shadow: 1px 1px 2px black, 0 0 25px #fefeff, 0 0 5px #c55ad2;
    color: yellow;
}

  </style>


  
</head>

<body>
<?php
    include("connection.php"); 


    $result1 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id = 1");
    while($res1 = mysqli_fetch_array($result1))
      {
        $heading1 = $res1['heading'];
        $content1 = $res1['content'];
      }

      $result2 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id = 2");
    while($res2 = mysqli_fetch_array($result2))
      {
        $heading2 = $res2['heading'];
        $content2 = $res2['content'];
      }

       $result3 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=3");
    while($res3 = mysqli_fetch_array($result3))
      {
        $heading3 = $res3['heading'];
        $content3 = $res3['content'];
      }

       $result4 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=4");
    while($res4 = mysqli_fetch_array($result4))
      {
        $heading4 = $res4['heading'];
        $content4 = $res4['content'];
      }

       $result5 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=5");
    while($res5 = mysqli_fetch_array($result5))
      {
        $heading5 = $res5['heading'];
        $content5 = $res5['content'];
      }

       $result6 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=6");
    while($res6 = mysqli_fetch_array($result6))
      {
        $heading6 = $res6['heading'];
        $content6 = $res6['content'];
      }

       $result7 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=7");
    while($res7 = mysqli_fetch_array($result7))
      {
        $heading7 = $res7['heading'];
        $content7 = $res7['content'];
      }

      

        $result8 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=8");
    while($res8 = mysqli_fetch_array($result8))
      {
        $heading8 = $res8['heading'];
        $content8 = $res8['content'];
      }

        $result9 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=9");
    while($res9 = mysqli_fetch_array($result9))
      {
        $heading9 = $res9['heading'];
        $content9 = $res9['content'];
      }

        $result10 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=10");
    while($res10 = mysqli_fetch_array($result10))
      {
        $heading10 = $res10['heading'];
        $content10 = $res10['content'];
      }

        $result11 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=11");
    while($res11 = mysqli_fetch_array($result11))
      {
        $heading11 = $res11['heading'];
        $content11 = $res11['content'];
      }

      $result12 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=12");
    while($res12 = mysqli_fetch_array($result12))
      {
        $heading12 = $res12['heading'];
        $content12 = $res12['content'];
      }

      $result13 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=13");
    while($res13 = mysqli_fetch_array($result13))
      {
        $heading13 = $res13['heading'];
        $content13 = $res13['content'];
      }

      $result14 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=14");
    while($res14 = mysqli_fetch_array($result14))
      {
        $heading14 = $res14['heading'];
        $content14 = $res14['content'];
      }

      $result15 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=15");
    while($res15 = mysqli_fetch_array($result15))
      {
        $heading15 = $res15['heading'];
        $content15 = $res15['content'];
      }

      $result16 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=16");
    while($res16 = mysqli_fetch_array($result16))
      {
        $heading16 = $res16['heading'];
        $content16 = $res16['content'];
      }

      $result17 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=17");
    while($res17 = mysqli_fetch_array($result17))
      {
        $heading17 = $res17['heading'];
        $content17 = $res17['content'];
      }

      $f18 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=18");
    while($faq18 = mysqli_fetch_array($f18))
      {
        $faqheading18 = $faq18['heading'];
        $faqcontent18 = $faq18['content'];
      }
     $f19 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=19");
    while($faq19 = mysqli_fetch_array($f19))
      {
        $faqheading19 = $faq19['heading'];
        $faqcontent19 = $faq19['content'];
      }
       $f20 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=20");
    while($faq20 = mysqli_fetch_array($f20))
      {
        $faqheading20 = $faq20['heading'];
        $faqcontent20 = $faq20['content'];
      }
       $f21 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=21");
    while($faq21 = mysqli_fetch_array($f21))
      {
        $faqheading21 = $faq21['heading'];
        $faqcontent21 = $faq21['content'];
      }
      $f22 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=22");
    while($faq22 = mysqli_fetch_array($f22))
      {
        $faqheading22 = $faq22['heading'];
        $faqcontent22 = $faq22['content'];
      }

       $indmob = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='indmob'");
    while($mob1 = mysqli_fetch_array($indmob))
      {
        $heading18 = $mob1['heading'];
        $content18 = $mob1['content'];
      }
       $usmob = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='usmob'");
    while($mob2 = mysqli_fetch_array($usmob))
      {
        $heading19 = $mob2['heading'];
        $content19 = $mob2['content'];
      }
       $lokahmail = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='mail'");
    while($mail1 = mysqli_fetch_array($lokahmail))
      {
        $heading20 = $mail1['heading'];
        $content20 = $mail1['content'];
      }

      $lokahaddress = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='address'");
    while($address1 = mysqli_fetch_array($lokahaddress))
      {
        $heading21 = $address1['heading'];
        $content21 = $address1['content'];
      }



       $facebooklink = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='facebooklink'");
    while($facebooklink2 = mysqli_fetch_array($facebooklink))
      {
        $heading22 = $facebooklink2['heading'];
        $content22 = $facebooklink2['content'];
      } 
      $linkedinlink = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='linkedinlink'");
    while($linkedinlink2 = mysqli_fetch_array($linkedinlink))
      {
        $heading23 = $linkedinlink2['heading'];
        $content23 = $linkedinlink2['content'];
      }
       $instagramlink = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='instagramlink'");
    while($instagramlink2 = mysqli_fetch_array($instagramlink))
      {
        $heading24 = $instagramlink2['heading'];
        $content24 = $instagramlink2['content'];
      }
       $youtubelink = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='youtubelink'");
    while($youtubelink2 = mysqli_fetch_array($youtubelink))
      {
        $heading25 = $youtubelink2['heading'];
        $content25 = $youtubelink2['content'];
      }
       $twitterlink = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='twitterlink'");
    while($twitterlink2 = mysqli_fetch_array($twitterlink))
      {
        $heading26 = $twitterlink2['heading'];
        $content26 = $twitterlink2['content'];
      }

       $logo = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='logo'");
    while($logo2 = mysqli_fetch_array($logo))
      {
        $logo3 = $logo2['heading'];
        $logo3 = $logo2['content'];
      }

      $result23 = mysqli_query($mysqli, "SELECT main_content.* FROM main_content where id=23");
    while($res23 = mysqli_fetch_array($result23))
      {
        $heading23 = $res23['heading'];
        $content23 = $res23['content'];
      }


        $slider_result1 = mysqli_query($mysqli, "SELECT homesliders.* FROM homesliders where image_order = 1");
    while($slider_res1 = mysqli_fetch_array($slider_result1))
      {
        $slider_image1 = $slider_res1['image'];
      }

      $slider_result2 = mysqli_query($mysqli, "SELECT homesliders.* FROM homesliders where image_order = 2");
    while($slider_res2 = mysqli_fetch_array($slider_result2))
      {
        $slider_image2 = $slider_res2['image'];
      }

       $slider_result3 = mysqli_query($mysqli, "SELECT homesliders.* FROM homesliders where image_order=3");
    while($slider_res3 = mysqli_fetch_array($slider_result3))
      {
        $slider_image3 = $slider_res3['image'];
      }

       $slider_result4 = mysqli_query($mysqli, "SELECT homesliders.* FROM homesliders where image_order=4");
    while($slider_res4 = mysqli_fetch_array($slider_result4))
      {
        $slider_image4 = $slider_res4['image'];
      }
      
  ?>

  <!-- ======= Header ======= -->



    <nav class="nav-menu top1">
        

      <img src="assets/img/<?php echo $logo3; ?>" alt="" class="img-fluid" style="height: 150px;width: 160px;">
        <img src="assets/img/lokahlogo.jpg" alt="" class="img-fluid">
           <ul class='ulll' style="float: right;margin-top: 55px;">
          <li><a><img src="assets/img/3.png" style="height: 20px;" class="blink-image">&nbsp;<b style="color: #000;"><?php echo $content20; ?></b></a></li>
           <li><a><img src="assets/img/6.png" style="height: 20px;" class="">&nbsp;<b style="color: #000;">US : <?php echo $content19; ?></b></a></li>&nbsp;

            <li><a><img src="assets/img/6.gif" style="height: 20px;" class="">&nbsp;<b style="color: #000;">IND : <?php echo $content18; ?></i></b></a></li></ul>
           

        
      </nav><!-- .nav-menu -->
  <header id="header" class="fixed-top sticky">
    <div class="container-fluid">

     

      <nav class="nav-menu d-none d-lg-block top2">
        <ul class="mob" style="padding-top:5px;">
          <li class="get-started"> <a href="<?php echo $content22; ?>" class="facebook"><i class="bx bxl-facebook fb2"></i></a></li>
          <li class="get-started"> <a href="<?php echo $content23; ?>" class="linkedin"><i class="bx bxl-linkedin li2"></i></a></li>
          <li class="get-started">  <a href="<?php echo $content24; ?>" class="instagram"><i class="bx bxl-instagram in2"></i></a></li>
          <li class="get-started">  <a href="<?php echo $content25; ?>" class="youtube"><i class="bx bxl-youtube yo2"></i></a></li>
          <li class="get-started"> <a href="<?php echo $content26; ?>" class="twitter"><i class="bx bxl-twitter tw2"></i></a></li>
          
          
          
            </ul>
        <ul class="header1" style="padding-top:5px;">
          <li class=""><a href="#hero">Home</a></li>
          <!--<li><a href="#aboutus">THEA GLOBAL</a></li>-->
          <li><a href="#aboutus1">About Us</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#h1btransfer">Immigration</a></li>
          <!--<li><a href="#eligibility">Eligibility</a></li>-->
          <li><a href="#portfolio">FAQ</a></li>
          <li><a href="#contact">Get In Touch</a></li>

         
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->
  <section id="about" class="about section1">
      <div class="container">

        <div class="row justify-content-between">
       <!--    <div class="col-lg-5 d-flex align-items-center justify-content-center about-img">
            <img src="assets/img/2.png" class="img-fluid" alt="" data-aos="zoom-in" style="height: 220px;">
          </div> -->
          <div class="col-lg-12 pt-5">
            <div class="aos-init aos-animate" data-aos="fade-up">
            <h3 data-aos="fade-up" class="aos-init aos-animate hhh" style="background-color: #ffa500;
    font-weight: 700;
    font-size: 24px;
    font-family: Calibri;
    color: #fff;
    border-radius: 20px;
    padding: 5px;
    border: 1px solid #509d4b;margin-top:100px;"><marquee><?php echo $content23; ?></marquee></h3>
          </div>
             

              </div>
            </div>
          </div>
     

      
    </section>