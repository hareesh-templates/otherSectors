 <?php include 'header.php'; ?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

  <h3 style="color: #eb5d1e;margin-left: 10%">Thank you. We will get back to you soon..!</h3><br>
  <span style="color: #eb5d1e;">&nbsp;&nbsp;(Please do not reload this page. It will be automatically redirect)</span>
  
  </section><!-- End Hero -->

  
<script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>
  
  <?php include 'footer.php'; ?>