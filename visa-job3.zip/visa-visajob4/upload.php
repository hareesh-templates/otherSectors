<?php
include_once 'database.php';
if(isset($_POST['upload']))
{   
	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$country = $_POST['country'];
	$comments = $_POST['comments'];
	$visatype = $_POST['visatype'];
	$added_on = date("d-m-Y");
     
 $file = rand(1000,100000)."-".$_FILES['file']['name'];
    $file_loc = $_FILES['file']['tmp_name'];
 $file_size = $_FILES['file']['size'];
 $file_type = $_FILES['file']['type'];
 $folder="upload/";
 

 $to = "info@lokah.co.in";
$subject = "LOKAH -".$fullname." - ".$visatype."";

$message = "
<html>
<head>
<title>LOKAH -".$fullname." - ".$visatype."</title>
</head>
<body>

<table>
<tr>
<th>Name</th>
<th>Email</th>
<th>Mobile</th>
<th>Country</th>
<th>Visa Type</th>
<th>Comment</th>
</tr>
<tr>
<td>".$fullname."</td>
<td>".$email."</td>
<td>".$mobile."</td>
<td>".$country."</td>
<td>".$visatype."</td>
<td>".$comments."</td>
</tr>
</table>
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <info@lokah.co.in>' . "\r\n";

mail($to,$subject,$message,$headers);





 $new_size = $file_size/1024;  
 
 $new_file_name = strtolower($file);
 
 $final_file=str_replace(' ','-',$new_file_name);
 
 if(move_uploaded_file($file_loc,$folder.$final_file))
 {
  $sql="INSERT INTO enqform(file,fullname,email,mobile,country,comments,visatype,added_on) VALUES('$final_file','$fullname','$email','$mobile','$country','$comments','$visatype','$added_on')";
  mysqli_query($conn,$sql);


$to = "info@lokah.co.in";
$subject = "LOKAH -".$fullname." - Enquiry Form";

$message = "<html>
<head>
<title>LOKAH  -".$fullname." - Enquiry Form</title>
</head>
<body>
<p>LOKAH  -".$fullname." - Enquiry Form</p>
<table>
<tr>
<th>Full Name</th>
<th>Email</th>
<th>Mobile</th>
<th>Country</th>
<th>Resume</th>
</tr>
<tr>
<td>".$fullname."</td>
<td>".$email."</td>
<td>".$mobile."</td>
<td>".$country."</td>
<td><a href='http://lokah.co.in/upload/".$final_file."'>Click Here</a></td>
</tr>
</table>
</body>
</html>";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <info@lokah.co.in>' . "\r\n";

mail($to,$subject,$message,$headers);



  
 header("Location: thankyou.php");        
  
 }
 else
 {
  
  echo "Error.Please try again";
		
		}
	}
?>