<?php include 'header.php'; ?>
<?php
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$loginId = $_SESSION['id'];
	$image_order = $_POST['image_order'];
	$file_name = $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
      
      $extensions= array("jpeg","jpg","png");
      
       move_uploaded_file($file_tmp,"assets/img/".$file_name);
		
	if(empty($file_name)) {
				
		if(empty($file_name)) {
			echo "<div class='container'><font color='red'>Image field is empty.</font><br/>";
		}
		
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a></div>";
	} else { 
		
		$result = mysqli_query($mysqli, "INSERT INTO homesliders(image,image_order) VALUES('$file_name','$image_order')");
		
		echo "<div class='container'><font color='green'>Data added successfully. </div><div class='container'><font color='red'>Please don't refresh this page</div>";
	}
}
?>
<script>
         setTimeout(function(){
            window.location.href = 'home_sliders.php';
         }, 5000);
      </script>
<?php include 'footer.php'; ?>
</body>
</html>
