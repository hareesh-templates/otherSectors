<?php
include_once("connection.php");

if(isset($_POST['update']))
{

	$id = $_POST['id'];
	$image_order = $_POST['image_order'];	
	$file_name = $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
      $extensions= array("jpeg","jpg","png");
      if($file_name == ''){
      	$file_name= $_POST['image1'];
      }
       move_uploaded_file($file_tmp,"assets/img/".$file_name);
	if(empty($file_name) || empty($image_order)) {
		if(empty($file_name)) {
			       echo $file_name; die();

			echo "<font color='red'>Image field is empty.</font><br/>";
		}			
	} else {	

		$result = mysqli_query($mysqli, "UPDATE homesliders SET image='$file_name', image_order='$image_order' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is view.php
		header("Location: home_sliders.php");
	}
}
?>