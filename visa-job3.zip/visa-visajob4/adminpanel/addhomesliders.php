<?php include 'header.php'; ?>
<div class="container">
<h2>Add Slider</h2>
	<form action="add_homesliders.php" method="post" name="myForm"  onsubmit="return validateForm()" enctype = "multipart/form-data">
	<div class="form-group">
       <label for="email">Image:</label> 
      <input type="file" class="form-control" id="name"  name="image">
    </div>
    <div class="form-group">
       <label for="email">Order:</label> 
      <input type="number" class="form-control" id="name"  name="image_order" placeholder="Image Oreder">
    </div>
    
    <input type="submit" name="Submit" value="Add" class="btn btn-success">
		
	</form>
</div>

<?php include 'footer.php'; ?>
</body>
</html>

