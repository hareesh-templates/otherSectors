<?php include 'header.php'; ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
include_once("connection.php");

if(isset($_POST['update']))
{	
	$session_id = $_SESSION['id'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$username = $_POST['username'];
  $password = $_POST['password'];
  $company = $_POST['company'];
	
	
	
	if(empty($name)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
	} else {	
		$result = mysqli_query($mysqli, "UPDATE login SET name='$name', email='$email', phonenumber='$phonenumber', username='$username', company='$company', password='$password' WHERE id=$session_id");
		
		header("Location: index.php");
	}
}
?>
<?php
$profile_id = $_GET['profile_id'];

$result = mysqli_query($mysqli, "SELECT * FROM login WHERE id=$profile_id");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$email = $res['email'];
	$username = $res['username'];
	$password = $res['password'];
	$company = $res['company'];
	
}
?>
<div class="container">
	<h2>Edit Profile</h2>
	
	<form name="myForm" method="post" action="#">
	<div class="form-group">
      <label for="email">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name"  value="<?php echo $name;?>" required>
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="name" placeholder="Enter Email" name="email"  value="<?php echo $email;?>"  required>
    </div>
     <div class="form-group">
      <label for="email">Company:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Company" name="company"  value="<?php echo $company;?>" required>
    </div>
     <div class="form-group">
      <label for="email">User Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter User Name" name="username"  value="<?php echo $username;?>" required>
    </div>
     <div class="form-group">
      <label for="email">Password:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Password" name="password"  value="<?php echo $password;?>">
    </div>
     
    <input type="submit" name="update" value="Update" class="btn btn-success">
		
	</form>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
