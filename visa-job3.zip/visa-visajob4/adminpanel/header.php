<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>LOKAH</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  .navbar-inverse .navbar-nav>li>a {
    color: #fff!important;
}
thead tr{
  background-color: maroon!important;
  color: #fff!important;
}
</style>
<body >

<nav class="navbar navbar-inverse"  style="background-color: maroon!important;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
        <?php
  if(isset($_SESSION['valid'])) {     
    include("connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
     $logo = mysqli_query($mysqli, "SELECT contact.* FROM contact where title='logo'");
    while($logo2 = mysqli_fetch_array($logo))
      {
        $logo3 = $logo2['heading'];
        $logo3 = $logo2['content'];
      }
  ?>
      <a class="navbar-brand" href="index.php"><img src="../assets/img/<?php echo $logo3; ?>" alt="" class="img-fluid" style="    margin-top: -20px;width: 50px;"></a>


<?php }else{ ?>
        <!-- <a class="navbar-brand" href="index.php"><img src="images/eglogo.png" style="height: 30px;"></a> -->
    <?php } ?>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      
      <ul class="nav navbar-nav navbar-right">
      	<?php
	if(isset($_SESSION['valid'])) {			
		include("connection.php");					
		$result = mysqli_query($mysqli, "SELECT * FROM login");
	?>
	 <li><a href="index.php"><span class="glyphicon glyphicon-user"></span><?php echo $_SESSION['name'] ?></a></li>
   <?php if($_SESSION['id'] == 1){ ?>
      <li><a href="enquiries.php">Enquiries</a></li>
      <li><a href="home_sliders.php">Sliders</a></li>
      <li><a href="content.php">Content</a></li>
      <li><a href="contact.php">Contact Info</a></li>
      <li><a href="edit_logo.php">Logo</a></li>
       
    <?php } ?>
  
  
	 <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
	 <?php }else{?>
       <!--  <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li> -->
        <!-- <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
    <?php } ?>

      </ul>
    </div>
  </div>
</nav>
  