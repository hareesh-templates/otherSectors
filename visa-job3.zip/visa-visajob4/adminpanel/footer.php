<style>
.footer {
	height: 50px;
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: maroon;
   color: white;
   text-align: center;
}
</style>
<br><br><br><br>
<div class="footer">
  <p style="padding-top: 15px;">Copyright © 2021 All rights reserved | Design and Developed By LOKAH</p>
</div>