<?php include 'header.php'; ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>


<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM homesliders WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$image = $res['image'];
	$image_order = $res['image_order'];
}
?>
<div class="container">
	<h2>Edit Gallery</h2>
	
	<form name="myForm"  onsubmit="return validateForm()" method="post" action="edit_homesliders.php" enctype = "multipart/form-data">
	<div class="form-group">
      <label for="email">Image:</label>
      <img src="assets/img/<?php echo $image;; ?>" width="100px" height="100px">
      <input type="file" class="form-control" id="name"  name="image"  value="<?php echo $image;?>">
    </div>
    <input type="text" name="image_order" value="<?php echo $image_order;?>" class="form-control">
    <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
    <input type="hidden" name="image1" value=<?php echo $image;?>>
    <input type="submit" name="update" value="Update" class="btn btn-success">
		
	</form>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
