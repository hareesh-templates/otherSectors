/*Author: smart*/
(function($){
	$.fn.accordion=function(o){
		this.each(function(){
			var th=$(this),
				data=th.data('accordion'),
				_={
					easing: 'linear',
					duraiton: '1000',
					delay: '0',
					contentHeight: 400,
                    addVal: 100,
                    height: 0,
                    liHeightClick: 50,
                    liHeight: 100,
                    holder: th.find('>ul'),
                    li: th.find('>ul>li'),
                    a: th.find('>ul>li>a'),
                    span: th.find('>ul>li>a>span'),
                    href: [],
                    length: 0,
                    notClass: '.noDisplay',
                    closeClass: '.close',
                    moreClass: '.moreClass',
                    prevInd: -99999,
                    currInd: -1,
                    defPadTop: 0,
                    defPadBot: 0,
                    defMarTop: 0,
                    defMarBot: 0,
                    defHeight: 0,
                    defMinHeight: parseInt($('body').css('minHeight')),
                    minHeight: 0,
                    change: function(){
                        _.onChange(_)
                        
                        _.prevInd = _.currInd;
                        for (var i=0;i<=_.length;i++){                            
                            if (_.href[i] != window.location.hash) {
                                if (i == (_.length-1)) {
                                    _.prevInd = -1;
                                    _.currInd = -2;
                                }
                            } else {
                                if (i == 0) i = -1;
                                _.currInd = i;
                                break;
                            }
                        }
                        if (_.prevInd != _.currInd)
                            switch (_.currInd){
                                case -2: _.more(); break;
                                case -1: _.close(); break;
                                default: _.animate(); break;
                            }
                    },
                    setMinHeight: function (h){
                        if (_.defMinHeight > h) {
                            h = _.defMinHeight
                        }
                        _.minHeight = h;             
                        
                        $('body').stop().animate({'minHeight':_.minHeight})
                    },
                    animate:function (){
                        _.height = _.liHeightClick*_.length + _.contentHeight;
                                                
                        _.setMinHeight(_.height+_.addVal)
                        _.click(_);
                        
                        _.li
                            .stop(true).animate({
                                'paddingTop':_.defPadTop,
                                'paddingBottom':_.defPadBot,
                                'marginBottom':_.defMarBot,
                                'height':_.liHeightClick
                            },_.duraiton,_.easing)
                            .eq(_.currInd).stop(true).animate({
                                'height':_.contentHeight,
                                'marginBottom':_.defMarBot
                            },_.duraiton,_.easing)
                    },
                    close: function (){
                        _.height = _.liHeight*_.length;
                        
                        _.setMinHeight(_.height)   
                        _.closeClick(_);
                        
                        _.height = _.liHeight*_.length - _.contentHeight;
                        _.li.stop(true).delay(_.delay).animate({
                            'paddingTop':_.defPadTop,
                            'paddingBottom':_.defPadBot,
                            'marginBottom':_.defMarBot,
                            'height':_.defHeight
                        },_.duraiton,_.easing)
                    },
					more:function(){                       
                        _.height = _.liHeightClick*_.length + _.contentHeight;
                        
                        _.setMinHeight(_.height)  
                        _.moreClick(_);
                                            
                        _.li
                            .stop(true).animate({
                            'paddingTop':_.defPadTop,
                            'paddingBottom':_.defPadBot,
                            /*'height':_.liHeightClick*/
                            'height':0
                        },_.duraiton,_.easing)
                            .eq(_.length-1).stop(true).animate({
                                'height':(_.liHeightClick),
                                'paddingTop':_.defPadTop,
                                'marginBottom':_.contentHeight
                            },_.duraiton,_.easing)
                    },
					init:function(){
                        _.holder = th.find('>ul');
                        _.li = th.find('>ul>li')
                        _.li = _.li.not(_.notClass);
                        _.a.each(function (){_.href.push($(this).attr('href'))})
                        
                        if (_.length == 0) _.length = _.li.length;
                        _.currInd = _.holder.find('.active').index();
                        
                        _.defPadTop = parseInt(_.li.css('paddingTop'))
                        _.defPadBot = parseInt(_.li.css('paddingBottom'))   
                        _.defMarTop = parseInt(_.li.css('marginTop'))
                        _.defMarBot = parseInt(_.li.css('marginBottom'))                   
                        _.defHeight = parseInt(_.li.css('height'))                     
                        _.contentHeight = parseInt(_.contentHeight)
                        _.addVal = parseInt(_.addVal)
                        _.liHeight = parseInt(_.li.outerHeight(true))
                        _.height = _.liHeight*_.length
                        _.liHeightClick = parseInt(_.liHeightClick);

                        $(window).bind('hashchange',function (){
                            _.change();
                        })
                        
                        $(window).resize(function () {
                            
                        })
                        
                        _.change();
                        switch (_.currInd){
                            case -2: _.more(); break;
                            case -1: _.close(); break;
                            default: _.animate(); break;
                        }
                    },
                    closeClick: function (_){
                    },
                    moreClick: function (_){
                    },
                    click: function (_){
                    },
                    onChange: function (_){
                    }
				}
			data?_=data:th.data({accordion:_})
			typeof o=='object'&&(_=$.extend(true,_,o))
			_.me||_.init(_.me=th)
			typeof o=='string'&&_.chngFu(o)
		})
		return this		
	}
})(jQuery)