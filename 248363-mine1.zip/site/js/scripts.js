include("js/jquery.animate-colors-min.js");
include("js/jquery.easing.js");
include("js/jquery.mousewheel.js");
include("js/uScroll.js");
include("js/googleMap.js");
include("js/superfish.js");
include("js/switcher.js");
include("js/forms.js");
include("js/accordion.js");
include("js/MathUtils.js");
include("js/jcarousellite.js");


function include(url) {
    document.write('<script src="' + url + '"></script>');
}
var MSIE = true, content, h = 0;
function addAllListeners() {
    }

$(document).ready(ON_READY);
$(window).load(ON_LOAD);

function ON_READY() {
}

function ON_LOAD(){
    MSIE = ($.browser.msie) && ($.browser.version <= 8);
    $('.spinner').delay(700).fadeOut();
    
    $('.scroll')
	.uScroll({			
		mousewheel:true			
		,lay:'outside'
	});
//for browsers------------------------------------------------------------------------------------------------
 if($.browser.msie && $.browser.version == 8){ 
    $('.list1 .date').css({'height':'36px', 'padding-top':'5px'});
    $('#page_privacy').css({'margin-bottom':'-39px'});
    $('#page_more').css({'margin-bottom':'-19px'});
    $('.btns').css({'padding-top':'7px'});
    }    
 if($.browser.msie && $.browser.version == 9){ 
    $('.btns').css({'padding-top':'7px'});
    }
 if($.browser.mozilla){ 
    $('.btns').css({'padding-top':'7px'});
    }
    
    //content switch
    content = $('#content');
    content.tabs({
        show:0,
        preFu:function(_){
            _.li.css({'display':'none'})
                .find('>div>div').css({'top':'1000px'})		
        },
        actFu:function(_){           
            if(_.curr){
                h = parseInt(_.curr.outerHeight(true));               
                
                _.curr
                    .css({'opacity':'0','display':'block'}).stop(true).animate({'opacity':'1'},{duration: 600,easing:'easeInOutExpo',complete:function (){
                        _.li.css({'display':'none'});
                        _.curr.css({'display':'block'})
                        $(window).trigger('resize');
                        if(_.n < 1){ 
                            $('.footer-menu>li').removeClass('_active');
                            $('#menu>li:first-child+li+li+li+li+li > a').stop().css({'border-bottom-color':'#d0d0d0'});
                            //$('body').stop().css({'overflow':'visible'});
                        }
                        if(_.n == 1){ 
                            $('.footer-menu>li').removeClass('_active');
                            $('.footer-menu>li:first-child').addClass('_active');
                        }
                        if(_.n == 2){ 
                            $('.footer-menu>li').removeClass('_active');
                            $('.footer-menu>li:first-child+li').addClass('_active')
                        }
                        if(_.n == 3){ 
                            $('.footer-menu>li').removeClass('_active');
                            $('.footer-menu>li:first-child+li+li').addClass('_active')
                        }
                        if(_.n == 4){ 
                            $('.footer-menu>li').removeClass('_active');
                            $('.footer-menu>li:first-child+li+li+li').addClass('_active')
                        }
                        if(_.n == 5){ 
                            $('.footer-menu>li').removeClass('_active');
                            $('.footer-menu>li:first-child+li+li+li+li').addClass('_active')
                            $('#menu>li:first-child+li+li+li+li+li > a').stop().css({'border-bottom-color':'transparent'});
                        }
                        if(_.n > 5){ 
                            $('.footer-menu>li').removeClass('_active');
                            //$('body').stop().css({'overflow':'hidden'});
                        }
                    }})
                    .find('>div>div').css({'top':'1000px','display':'block'}).stop(true,true).show().animate({'top':'0'},1000,'easeOutExpo');
            }   
    		if(_.prev){
  		        _.prev
                   .stop(true).animate({'opacity':'0'},200,'easeInOutExpo',function(){
                        if (_.prev){
                            _.prev.css({'display':'none'});
                        }
                    })
                    .find('>div>div').stop(true,true).animate({'top':'1000px'},400,'easeInOutExpo')
            }            
  		}
    });
//Main menu---------------------------------------------------------------------------------------------------
    $('.footer-menu').superfish({
          delay:       500,
          //animation:   {height:'show'},
          speed:       600,
          autoArrows:  false,
         dropShadows: false
    });
    
    var nav = $('.menu');
    nav.navs({
		useHash:true,
        defHash: '#!/page_splash',
        hoverIn:function(li){
            $('strong', li).stop().animate({'opacity':1},650,'easeOutExpo');
            $('strong > img', li).stop().animate({'margin-top':0},650,'easeOutExpo');
            $('>span', li).stop().animate({'opacity':1},650,'easeOutExpo');
        },
        hoverOut:function(li){
            if ((!li.hasClass('with_ul')) || (!li.hasClass('sfHover'))) {
                $('strong', li).stop().animate({'opacity':0},650,'easeOutExpo');
                $('strong > img', li).stop().animate({'margin-top':'120px'},650,'easeOutExpo');
                $('>span', li).stop().animate({'opacity':0},1200,'easeOutExpo');
            }
        }
    })
    .navs(function(n,_){
   	    $('#content').tabs(n);
        if (_.prevHash == '#!/page_contacts') { 
            $('#form1 a').each(function (ind, el){
                if ($(this).attr('data-type') == 'reset') { $(this).trigger('click') }   
            })
        }
   	});
    
    setTimeout(function(){  $('body').css({'overflow':'visible'}); },300);    
    addAllListeners();
    
    $('.menu').accordion({
        moreClass: '.more, .moreLink',
        notClass: '.no_disp',
        contentHeight: 400,
        liHeightClick:76,
        delay: 300,
        onChange: function(_){ _.contentHeight = h;},
        click: function (_){
            _.span.stop(true).animate({'lineHeight':'76px'},_.duraiton,_.easing)
                .eq(_.currInd).stop(true).animate({'lineHeight':'76px'},_.duraiton,_.easing);
                $('.menu').stop(true).animate({opacity:1},650, "easeOutExpo");
                if($.browser.msie && $.browser.version == 8){ 
                    $('#menu>li').stop(true).css({opacity:1});
                    }
                
        },
        closeClick: function (_){
            _.span.stop(true).delay(_.delay).animate({'lineHeight':'76px'},_.duraiton,_.easing);
            $('.menu').stop(true).animate({opacity:1},650, "easeOutExpo");
            if($.browser.msie && $.browser.version == 8){ 
                $('#menu>li').stop(true).css({opacity:1});
                }
            },
        moreClick: function (_){
            _.span.stop(true).animate({'lineHeight':'76px'},_.duraiton,_.easing);
            $('.menu').stop(true).animate({opacity:0},350, "easeOutExpo");
            if($.browser.msie && $.browser.version == 8){ 
                    $('#menu>li').stop(true).css({opacity:0});
                    }	
            },
        addVal: $('header').height()+$('footer').height(),
        duration: 1000,
        easing: 'easeInOutExpo'
    });    
    $(window).trigger('resize');
//Hover-------------------------------------------------------------------------------------------------------
    $('.more').hover(function(){
        $(this).stop().animate({color:'#6a6a69'},350, "easeOutSine");		 
            }, function(){
        $(this).stop().animate({color:'#161616'},350, "easeOutSine");				 
    })
    $('.prev img').css({opacity:0})
    $('.prev').hover(function(){
        $(this).find('img').stop().animate({opacity:1},350, "easeOutSine");		 
            }, function(){
        $(this).find('img').stop().animate({opacity:0},350, "easeOutSine");					 
    })
    $('.next img').css({opacity:0})
    $('.next').hover(function(){
        $(this).find('img').stop().animate({opacity:1},350, "easeOutSine");		 
            }, function(){
        $(this).find('img').stop().animate({opacity:0},350, "easeOutSine");					 
    })
    $('.list2 li a').hover(function(){
        $(this).stop().animate({color:'#6a6a69'},350, "easeOutSine");		 
            }, function(){
        $(this).stop().animate({color:'#1c1c1c'},350, "easeOutSine");				 
    })
    $('.list3 li a').hover(function(){
        $(this).stop().animate({color:'#6a6a69'},350, "easeOutSine");		 
            }, function(){
        $(this).stop().animate({color:'#1c1c1c'},350, "easeOutSine");				 
    })
    $('.info a').hover(function(){
        $(this).stop().animate({color:'#6a6a69'},350, "easeOutSine");		 
            }, function(){
        $(this).stop().animate({color:'#0f0f0f'},350, "easeOutSine");				 
    }) 
    $('.cross .img_act').css({opacity:0});
    $('.cross').hover(function(){
        $(this).find('.img_act').stop().animate({opacity:1},350, "easeOutSine");		 
            }, function(){
        $(this).find('.img_act').stop().animate({opacity:0},350, "easeOutSine");				 
    })
}

$(window).resize(function (){
    //if (content) content.stop().animate({'top':(windowH()-content.height())*.5},500);
});